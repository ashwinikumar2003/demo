import { createContext, useState, useEffect, useContext } from 'react'
import { login as apiLogin, register as apiRegister } from '../api/auth'

export const AuthContext = createContext()

export function AuthProvider({ children }) {
  const [token, setToken] = useState(() => localStorage.getItem('token'))
  const [user, setUser]   = useState(null)

  useEffect(() => {
    if (token) {
      const payload = JSON.parse(atob(token.split('.')[1]))
      setUser({ id: payload.id, email: payload.sub, role: payload.role })
      localStorage.setItem('token', token)
    } else {
      setUser(null);
      localStorage.removeItem('token')
    }
  }, [token]);

  const login = (creds) => apiLogin(creds).then(r => setToken(r.data.data.token))
  const register = (info) => apiRegister(info).then(r => setToken(r.data.data.token))
  const logout = () => setToken(null)

  return (
    <AuthContext.Provider value={{ token, user, login, register, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}