import { useState, useContext } from 'react'
import { Link, Navigate, useNavigate } from 'react-router-dom'
import { toast } from 'react-toastify'
import { AuthContext } from '../contexts/AuthContext'
import { FaUser, FaEnvelope, FaLock, FaCheckCircle } from 'react-icons/fa'
import '../styles/AuthForms.css'

export default function Register() {
  const [form, setForm] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: '',
    role: 'ROLE_USER'
  })
  const [errors, setErrors] = useState({})
  const [isLoading, setIsLoading] = useState(false)
  
  const { register, user } = useContext(AuthContext)
  const navigate = useNavigate()

  if (user) {
    return <Navigate to="/dashboard" replace />
  }

  const handleChange = (e) => {
    const { name, value } = e.target
    setForm(prev => ({
      ...prev,
      [name]: value
    }))
  }

  const validateForm = () => {
    const newErrors = {}
    
    if (!form.name.trim()) {
      newErrors.name = 'Name is required'
    }
    
    if (!form.email.trim()) {
      newErrors.email = 'Email is required'
    } else if (!/\S+@\S+\.\S+/.test(form.email)) {
      newErrors.email = 'Email is invalid'
    }
    
    if (!form.password) {
      newErrors.password = 'Password is required'
    } else if (form.password.length < 6) {
      newErrors.password = 'Password must be at least 6 characters'
    }
    
    if (form.password !== form.confirmPassword) {
      newErrors.confirmPassword = 'Passwords do not match'
    }
    
    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    
    if (!validateForm()) return
    
    setIsLoading(true)
    
    try {
      await register({
        name: form.name,
        email: form.email,
        password: form.password,
        role: form.role
      })
      toast.success('Registration successful!')
      navigate('/dashboard')
    } catch (error) {
      let errorMessage = 'Registration failed'
      
      if (error.response) {
        errorMessage = error.response.data.message || errorMessage
      }
      
      toast.error(errorMessage)
      setIsLoading(false)
    }
  }

  return (
    <div className="auth-container">
      <div className="auth-form-container">
        <h2>Create Account</h2>
        <form onSubmit={handleSubmit} className="auth-form">
          <div className="form-group">
            {/* <label htmlFor="name">Name</label> */}
            <div style={{ display: 'flex', alignItems: 'center' }}>
              <FaUser style={{ marginRight: 8, color: '#333' }} />
              <input
                type="text"
                id="name"
                name="name"
                value={form.name}
                onChange={handleChange}
                placeholder="Your name"
                className={errors.name ? 'input-error' : ''}
                style={{ flexGrow: 1 }}
              />
            </div>
            {errors.name && <div className="error-message">{errors.name}</div>}
          </div>
          
          <div className="form-group">
            {/* <label htmlFor="email">Email</label> */}
            <div style={{ display: 'flex', alignItems: 'center' }}>
              <FaEnvelope style={{ marginRight: 8, color: '#333' }} />
              <input
                type="email"
                id="email"
                name="email"
                value={form.email}
                onChange={handleChange}
                placeholder="your@email.com"
                className={errors.email ? 'input-error' : ''}
                style={{ flexGrow: 1 }}
              />
            </div>
            {errors.email && <div className="error-message">{errors.email}</div>}
          </div>
          
          <div className="form-group">
            {/* <label htmlFor="password">Password</label> */}
            <div style={{ display: 'flex', alignItems: 'center' }}>
              <FaLock style={{ marginRight: 8, color: '#333' }} />
              <input
                type="password"
                id="password"
                name="password"
                value={form.password}
                onChange={handleChange}
                placeholder="Create a password"
                className={errors.password ? 'input-error' : ''}
                style={{ flexGrow: 1 }}
              />
            </div>
            {errors.password && <div className="error-message">{errors.password}</div>}
          </div>
          
          <div className="form-group">
            {/* <label htmlFor="confirmPassword">Confirm Password</label> */}
            <div style={{ display: 'flex', alignItems: 'center' }}>
              <FaCheckCircle style={{ marginRight: 8, color: '#333' }} />
              <input
                type="password"
                id="confirmPassword"
                name="confirmPassword"
                value={form.confirmPassword}
                onChange={handleChange}
                placeholder="Confirm your password"
                className={errors.confirmPassword ? 'input-error' : ''}
                style={{ flexGrow: 1 }}
              />
            </div>
            {errors.confirmPassword && (
              <div className="error-message">{errors.confirmPassword}</div>
            )}
          </div>
          {/*           
          <div className="form-group">
            <label htmlFor="role" style={{color:"#222"}}>Account Type</label>
            <select
              id="role"
              name="role"
              value={form.role}
              onChange={handleChange}
            >
              <option value="ROLE_USER">User</option>
              <option value="ROLE_ADMIN">Admin</option>
            </select>
          </div> */}
          
          <button 
            type="submit" 
            className="auth-button" 
            disabled={isLoading || !form.name || !form.email || !form.password || !form.confirmPassword || Object.keys(errors).length > 0}
          >
            {isLoading ? 'Creating Account...' : 'Register'}
          </button>
        </form>
        
        <div className="auth-links">
          <p>
            Already have an account? <Link to="/login"><button style={{cursor:"pointer", borderRadius:"5px", color:"white", background:"purple", height:"30px"}}>Log In</button></Link>
          </p>
        </div>
      </div>
    </div>
  )
}
