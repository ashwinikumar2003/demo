import React, { useEffect, useState } from 'react'
import { getProfile, updateProfile, updatePassword } from '../api/profile'
import { useAuth } from '../contexts/AuthContext'
import '../styles/Forms.css'
import { FaUserCircle } from "react-icons/fa";

export default function Profile() {
  const { token } = useAuth()
  const [profile, setProfile] = useState({ name: '', email: '', role: '' })
  const [edit, setEdit] = useState(false)
  const [form, setForm] = useState({ name: '', email: '' })
  const [passwordForm, setPasswordForm] = useState({ oldPassword: '', newPassword: '' })
  const [loading, setLoading] = useState(false)
  const [message, setMessage] = useState('')

  useEffect(() => {
    async function fetchProfile() {
      setLoading(true)
      try {
        const data = await getProfile(token)
        setProfile(data)
        setForm({ name: data.name, email: data.email })
      } catch (e) {
        setMessage('Failed to load profile')
      }
      setLoading(false)
    }
    fetchProfile()
  }, [token])

  const handleEdit = () => setEdit(true)
  const handleCancel = () => {
    setEdit(false)
    setForm({ name: profile.name, email: profile.email })
    setMessage('')
  }
  const handleChange = e => setForm(f => ({ ...f, [e.target.name]: e.target.value }))
  const handlePasswordChange = e => setPasswordForm(f => ({ ...f, [e.target.name]: e.target.value }))

  const handleSave = async e => {
    e.preventDefault()
    setLoading(true)
    setMessage('')
    try {
      const updated = await updateProfile(token, form)
      setProfile(updated)
      setEdit(false)
      setMessage('Profile updated successfully')
    } catch (e) {
      setMessage(e.message || 'Update failed')
    }
    setLoading(false)
  }

  const handlePasswordSubmit = async e => {
    e.preventDefault()
    setLoading(true)
    setMessage('')
    try {
      await updatePassword(token, passwordForm)
      setPasswordForm({ oldPassword: '', newPassword: '' })
      setMessage('Password updated successfully')
    } catch (e) {
      setMessage(e.message || 'Password update failed')
    }
    setLoading(false)
  }

  return (
    <div className="form-container profile-page">
      <FaUserCircle size={54} />
      <h2>My Profile</h2>
      {loading && <div className="loading">Loading...</div>}
      {message && <div className="form-message">{message}</div>}
      <form onSubmit={handleSave} className="profile-form">
        <label>Name</label>
        <input name="name" value={form.name} onChange={handleChange} disabled={!edit} />
        <label>Email</label>
        <input name="email" value={form.email} onChange={handleChange} disabled={!edit} />
        <label>Role</label>
        <input value={profile.role} disabled readOnly />
        {!edit ? (
          <button type="button" onClick={handleEdit} className="primary-btn">Edit</button>
        ) : (
          <div className="form-actions">
            <button type="submit" className="primary-btn">Save</button>
            <button type="button" onClick={handleCancel} className="secondary-btn">Cancel</button>
          </div>
        )}
      </form>
      <hr />
      <form onSubmit={handlePasswordSubmit} className="profile-form">
        <h3>Change Password</h3>
        <label>Old Password</label>
        <input name="oldPassword" type="password" value={passwordForm.oldPassword} onChange={handlePasswordChange} required />
        <label>New Password</label>
        <input name="newPassword" type="password" value={passwordForm.newPassword} onChange={handlePasswordChange} required />
        <button type="submit" className="primary-btn">Update Password</button>
      </form>
    </div>
  )
}
