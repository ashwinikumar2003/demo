
import { useContext } from 'react'
import { Link, Navigate } from 'react-router-dom'
import { AuthContext } from '../contexts/AuthContext'
import { FaChartPie, FaBell, FaMoneyBillWave } from 'react-icons/fa'
import '../styles/Welcome.css'

const features = [
  {
    icon: <FaChartPie />,
    title: 'Track Expenses',
    desc: 'See all your subscriptions and their costs at a glance.',
  },
  {
    icon: <FaBell />,
    title: 'Payment Reminders',
    desc: 'Get timely alerts so you never miss a billing date.',
  },
  {
    icon: <FaMoneyBillWave />,
    title: 'Save Money',
    desc: 'Spot under-used subs and optimize your budget.',
  },
]

export default function Welcome() {
  const { user } = useContext(AuthContext)
  if (user) return <Navigate to="/dashboard" replace />

  return (
    <section className="welcome">
      <div className="welcome__hero">
        <h1>ManageMySubs</h1>
        <p>Your one-stop hub to track, remind & optimize subscriptions.</p>
        <div className="welcome__cta">
          <Link to="/register" className="btn primary1">Sign Up</Link>
          <Link to="/login" className="btn secondary1">Log In</Link>
        </div>
      </div>

      <div className="welcome__features">
        {features.map(({ icon, title, desc }) => (
          <div key={title} className="feature-card" data-aos="fade-up">
            <div className="feature-card__icon">{icon}</div>
            <h3>{title}</h3>
            <p>{desc}</p>
          </div>
        ))}
      </div>
    </section>
  )
}