import { useContext, useEffect, useState } from 'react'
import { getPaymentsBySubscription, getPaymentsByUser } from '../api/payment'
import { AuthContext } from '../contexts/AuthContext'
import '../styles/Lists.css'

export default function PaymentList({ subscriptionId }) {
  const { token } = useContext(AuthContext)
  const [payments, setPayments] = useState([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState(null)

  const loadPayments = async () => {
    setIsLoading(true)
    try {
      let data;
      if (subscriptionId) {
        data = await getPaymentsBySubscription(subscriptionId, token);
      } else {
        data = await getPaymentsByUser(token);
      }
      setPayments(data || [])
      setError(null)
    } catch (err) {
      setError('Failed to load payments. Please try again.')
      console.error('Error loading payments:', err)
    } finally {
      setIsLoading(false)
    }
  }

  useEffect(() => {
    loadPayments()
    console.log(payments)
  }, [subscriptionId, token])

  if (isLoading) {
    return <div className="loading-indicator">Loading payments...</div>
  }

  if (error) {
    return <div className="error-message">{error}</div>
  }

  if (payments.length === 0) {
    return (
      <div className="empty-state">
        <div className="empty-icon">💰</div>
        <div className="message">No payments found</div>
        <p>Click the "Add Payment" button to record a payment{subscriptionId ? " for this subscription" : ""}.</p>
      </div>
    )
  }

  // Format date from ISO to readable format
  const formatDate = (isoDate) => {
    if (!isoDate) return 'N/A'
    return new Date(isoDate).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    })
  }

  return (
    <div className="list-container">
      <table className="list-table">
        <thead>
          <tr>
            {!subscriptionId && <th>Subscription ID</th>}
            <th>Payment Date</th>
            <th>Amount</th>
            <th>Payment Method</th>
            <th>Status</th>
            <th>Notes</th>
          </tr>
        </thead>
        <tbody>
          {payments.map((payment) => (
            <tr key={payment.id}>
              {!subscriptionId && <td>#{payment.subscriptionId}</td>}
              <td>{formatDate(payment.paymentDate)}</td>
              <td>
                {payment.amount} {payment.currency}
              </td>
              <td>{payment.paymentMethod}</td>
              <td>
                <span className={`status ${payment.status.toLowerCase()}`}>
                  {payment.status}
                </span>
              </td>
              <td className="notes-cell">
                {payment.notes ? payment.notes : <em>No notes</em>}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}