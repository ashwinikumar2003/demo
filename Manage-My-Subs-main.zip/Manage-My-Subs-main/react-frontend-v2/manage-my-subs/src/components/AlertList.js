import { useState, useEffect, useContext } from 'react'
import { getUserAlerts } from '../api/alerts'
import { AuthContext } from '../contexts/AuthContext'
import '../styles/AlertList.css'

export default function AlertList() {
  const { token } = useContext(AuthContext)
  const [alerts, setAlerts] = useState([])

  useEffect(() => {
    const fetch = async () => {
      const data = await getUserAlerts(token)
      setAlerts(data)
    }
    fetch()
  }, [token])

  return (
    <div className="alert-list">
      <h3>Upcoming Alerts</h3>
      <ul>
        {alerts.map(alert => (
          <li key={alert.id}>
            📅 <strong>{new Date(alert.alertDate).toLocaleDateString()}</strong>: {alert.message}
          </li>
        ))}
      </ul>
    </div>
  )
}