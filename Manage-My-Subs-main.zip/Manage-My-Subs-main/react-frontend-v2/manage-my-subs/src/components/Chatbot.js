import React, { useState, useRef, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { fetchSubscriptions } from '../api/subscriptions';
import { getPaymentsByUser } from '../api/payment';
import { AzureOpenAI } from 'openai';
import '../styles/Chatbot.css';

const Chatbot = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState([
    { role: 'assistant', content: 'Hi! I can help you with your subscriptions and payments. What would you like to know?' }
  ]);
  const [contextData, setContextData] = useState(null);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef(null);
  const { token } = useAuth();


  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const loadContextData = async () => {
    try {
      const subscriptions = await fetchSubscriptions(token)
      const payments = await getPaymentsByUser(token)
      
      const data = { subscriptions: subscriptions.data, payments: payments.data };
      setContextData(data);
      return data;
    } catch (error) {
      console.log("Error occured while fetching data")
      const data = { subscriptions: [], payments: [] };
      setContextData(data);
      return data;
    }
  };

  const callAzureOpenAI = async (userMessage, contextData) => {
    try {
      console.log('API Key exists:', !!process.env.REACT_APP_AZURE_OPENAI_KEY);
      const contextString = JSON.stringify(contextData, null, 2);
      const response = await fetch('https://ashwi-mgri7zoi-eastus2.cognitiveservices.azure.com/openai/deployments/o4-mini/chat/completions?api-version=2024-12-01-preview', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'api-key': process.env.REACT_APP_AZURE_OPENAI_KEY
         
        },
        body: JSON.stringify({
          
          messages: [
            { role: 'system', content: `You are a helpful assistant of a subscription manager application. Be concise.`},
            { role: 'system', content: `User context: ${contextString}`},
            { role: 'user', content: userMessage }
          ],
          max_completion_tokens: 1000,
          temperature: 1
        })
      }
    );

      if (!response.ok) {
        console.error('API Error:', response.status, await response.text());
        return `API Error: ${response.status}. Check your API key and endpoint.`;
      }

      const data = await response.json();
      return data.choices[0].message?.content || data.choices[0].messages?.[0]?.content;
    } catch (error) {
      console.error('Connection error:', error);
      return `Connection error: ${error.message}`;
    }
  };

  const handleSend = async () => {
    if (!input.trim()) return;

    const userMessage = input.trim();
    setInput('');
    setMessages(prev => [...prev, { role: 'user', content: userMessage }]);
    setIsLoading(true);

    try {
      const data = await loadContextData();
      console.log('Context data loaded:', data);
      const response = await callAzureOpenAI(userMessage, data);
      setMessages(prev => [...prev, { role: 'assistant', content: response }]);
    } catch (error) {
      console.error('Handle send error:', error);
      setMessages(prev => [...prev, { 
        role: 'assistant', 
        content: `Error: ${error.message}` 
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <>
      <div className={`chatbot-toggle ${isOpen ? 'open' : ''}`} onClick={() => setIsOpen(!isOpen)}>
        💬
      </div>
      
      {isOpen && (
        <div className="chatbot-container">
          <div className="chatbot-header">
            <h3>Subscription Assistant</h3>
            <button onClick={() => setIsOpen(false)}>×</button>
          </div>
          
          <div className="chatbot-messages">
            {messages.map((message, index) => (
              <div key={index} className={`message ${message.role}`}>
                <div className="message-content">
                  {message.content}
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="message assistant">
                <div className="message-content typing">
                  <span></span><span></span><span></span>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>
          
          <div className="chatbot-input">
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Ask about your subscriptions..."
              rows="2"
            />
            <button onClick={handleSend} disabled={isLoading || !input.trim()}>
              Send
            </button>
          </div>
        </div>
      )}
    </>
  );
};

export default Chatbot;