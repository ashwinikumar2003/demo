import { useState, useEffect, useContext, useRef } from 'react';
import { getUserAlerts } from '../api/alerts';
import { AuthContext } from '../contexts/AuthContext';
import '../styles/AlertDropdown.css';

export default function AlertDropdown({ visible, onClose }) {
  const { token } = useContext(AuthContext);
  const [alerts, setAlerts] = useState([]);
  const dropdownRef = useRef(null);

  useEffect(() => {
    if (visible) {
      getUserAlerts(token).then(setAlerts);
    }
  }, [visible, token]);

  useEffect(() => {
    if (!visible) return;
    function handleClickOutside(event) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        onClose();
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [visible, onClose]);

  if (!visible) return null;

  return (
    <div className="alert-dropdown" ref={dropdownRef}>
      <div className="alert-dropdown-header">
        <span>Alerts</span>
        <button className="close-btn" onClick={onClose}>&times;</button>
      </div>
      <ul className="alert-dropdown-list">
        {alerts.length === 0 ? (
          <li className="empty-alert">No alerts</li>
        ) : (
          alerts.map(alert => (
            <li key={alert.id} className={alert.isRead ? 'read' : 'unread'}>
              <span role="img" aria-label="calendar">📅</span> <strong>{new Date(alert.alertDate).toLocaleDateString()}</strong>: {alert.alertMessage}
            </li>
          ))
        )}
      </ul>
    </div>
  );
}
