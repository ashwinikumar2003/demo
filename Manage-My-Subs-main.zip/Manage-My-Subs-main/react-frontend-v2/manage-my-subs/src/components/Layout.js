import { useContext, useState, useEffect } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { AuthContext } from '../contexts/AuthContext';
import { getUserAlerts } from '../api/alerts';
import { MdSubscriptions } from "react-icons/md";
import { FaUserCircle } from 'react-icons/fa';
import { IoIosNotifications } from "react-icons/io";
import AlertDropdown from './AlertDropdown';
import Chatbot from './Chatbot';
import '../styles/Layout.css';

export default function Layout({ children }) {
  const { user, logout, token } = useContext(AuthContext);
  const navigate = useNavigate();
  const location = useLocation();
  const [alertOpen, setAlertOpen] = useState(false);
  const [hasUnreadAlerts, setHasUnreadAlerts] = useState(false);

  useEffect(() => {
    if (user && token) {
      checkUnreadAlerts();
      const interval = setInterval(checkUnreadAlerts, 30000);
      return () => clearInterval(interval);
    }
  }, [user, token]);

  const checkUnreadAlerts = async () => {
    try {
      const alerts = await getUserAlerts(token);
      const unreadCount = alerts.filter(alert => !alert.isRead).length;
      setHasUnreadAlerts(unreadCount > 0);
    } catch (error) {
      console.error('Failed to fetch alerts:', error);
    }
  };

  const handleAlertToggle = () => {
    setAlertOpen(v => !v);
    if (!alertOpen) {
      setHasUnreadAlerts(false);
    }
  };

  const handleLogout = () => {
    logout();
    navigate('/welcome');
  };

  const isAuthPage = location.pathname === '/login' || location.pathname === '/register' || location.pathname === '/welcome';

  return (
    <div className="app-container">
      {!isAuthPage && (
        <header className="app-header">
          <div className="header-content">
            <div className="logo">
              <Link to={user ? '/dashboard' : '/welcome'}>
                <div className="logo-text" style={{display: 'flex', alignItems: 'center', gap:'0.5rem'}}>
                  <MdSubscriptions size={36} color='blue'/>
                  <h1>ManageMySubs</h1>
                </div>
              </Link>
            </div>
            <nav className="main-nav">
              {user ? (
                <div className="nav-user-section">
                  <div className="notifications" style={{ position: 'relative' }}>
                    <button className={`icon-button ${hasUnreadAlerts ? 'notification-glow' : ''}`} onClick={handleAlertToggle}>
                      <IoIosNotifications size={24}/>
                      {hasUnreadAlerts && <span className="notification-dot"></span>}
                    </button>
                    <AlertDropdown visible={alertOpen} onClose={() => setAlertOpen(false)} />
                  </div>
                  <div>
                    <FaUserCircle size={24} style={{cursor:"pointer"}} color='#444' onClick={() => navigate('/profile')} />
                  </div>
                  <div className="user-info">
                    
                    <span className="username">{user.email}</span>
                    <span className="role">{user.role.substring(5)}</span>
                  </div>
                  <button onClick={handleLogout} style={{fontWeight:"600", borderWidth:"2px"}} className="btn-logout">
                    Log out
                  </button>
                </div>
              ) : (
                <div className="nav-auth-buttons">
                  <Link to="/login" className="btn btn-secondary">
                    Log in
                  </Link>
                  <Link to="/register" className="btn btn-primary">
                    Register
                  </Link>
                </div>
              )}
            </nav>
          </div>
        </header>
      )}
      <main className="app-main">{children}</main>
      {user && <Chatbot />}
    </div>
  );
}