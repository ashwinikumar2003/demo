import React, { useEffect, useState, useContext } from 'react'
import { AuthContext } from '../contexts/AuthContext'
import { fetchSubscriptions } from '../api/subscriptions'
import { FaRupeeSign, FaChartLine, FaCheck} from "react-icons/fa"
import { FaChartSimple } from "react-icons/fa6"
import '../styles/Dashboard.css'

const icons = [
  <div className="analytics-icon placeholder"><FaRupeeSign color='#4254f4'/></div>,
  <div className="analytics-icon placeholder"><FaChartLine color='#fb9804'/></div>,
  <div className="analytics-icon placeholder"><FaCheck color='#34a853'/></div>,
  <div className="analytics-icon placeholder"><FaChartSimple color='#a835ea'/></div>,
]

const AnalyticsCards = (props) => {
  const { token } = useContext(AuthContext)
  const [subscriptions, setSubscriptions] = useState([])
  const [loading, setLoading] = useState(true)
  const updateAt = props.updateAt

  useEffect(() => {
    const load = async () => {
      try {
        const res = await fetchSubscriptions(token)
        setSubscriptions(res.data.data || [])
      } catch (e) {
        setSubscriptions([])
      } finally {
        setLoading(false)
      }
    }
    load()
  }, [token, updateAt])


  
const frequencyToMonthlyFactor = {
 WEEKLY: 4.345,
 MONTHLY: 1,
 QUARTERLY: 1 / 3,
 YEARLY: 1 / 12
}


const activeSubs = subscriptions.filter(s => s.active !== false)
console.log(activeSubs)
  
const totalMonthly = activeSubs.reduce((sum, sub) => {
 if (!sub.active) return sum

 const amount = parseFloat(sub.amount) || 0
 const frequency = sub.frequency?.toUpperCase()
 const factor = frequencyToMonthlyFactor[frequency] || 0

 return sum + amount * factor;
}, 0)

  const yearlyProjection = totalMonthly * 12
  const activeCount = activeSubs.length
  const avgCost = activeCount > 0 ? totalMonthly / activeCount : 0

  const analytics = [
    {
      label: 'Total Monthly Spending',
      value: loading ? '...' : `₹${totalMonthly.toFixed(2)}`,
      icon: icons[0],
      color: 'primary',
    },
    {
      label: 'Yearly Projection',
      value: loading ? '...' : `₹${yearlyProjection.toFixed(2)}`,
      icon: icons[1],
      color: 'secondary',
    },
    {
      label: 'Active Subscriptions',
      value: loading ? '...' : activeCount,
      icon: icons[2],
      color: 'success',
    },
    {
      label: 'Avg Cost per Service',
      value: loading ? '...' : `₹${avgCost.toFixed(2)}`,
      icon: icons[3],
      color: 'warning',
    },
  ]

  return (
    <div className="analytics-cards-container">
      {analytics.map((card, idx) => (
        <div key={idx} className={`analytics-card ${card.color}`}>
          {card.icon}
          <div className="analytics-info">
            <div className="analytics-value">{card.value}</div>
            <div className="analytics-label">{card.label}</div>
          </div>
        </div>
      ))}
    </div>
  )
}

export default AnalyticsCards