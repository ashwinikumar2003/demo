import React, { useEffect, useState } from 'react';
import { getAllUsers, deactivateUser, updateUserRole } from '../api/admin';
import { useAuth } from '../contexts/AuthContext';
import '../styles/Lists.css';

export default function AdminDashboard() {
  const { token, user } = useAuth();
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState('');

  useEffect(() => {
    async function fetchUsers() {
      setLoading(true);
      try {
        const data = await getAllUsers(token);
        setUsers(data);
      } catch (e) {
        setMessage('Failed to load users');
      }
      setLoading(false);
    }
    if (user?.role === 'ROLE_ADMIN') fetchUsers();
  }, [token, user]);

  const totalUsers = users.length

  const handleRoleChange = async (id, newRole) => {
    setLoading(true)
    setMessage('')
    try {
      const updated = await updateUserRole(token, id, newRole)
      setUsers(users => users.map(u => u.id === id ? { ...u, role: updated.role } : u))
      setMessage('Role updated')
    } catch (e) {
      setMessage('Failed to update role')
    }
    setLoading(false);
  }

  const handleDelete = async (id) => {
    if (!window.confirm('Are you sure you want to delete this user? This action cannot be undone.')) return;
    setLoading(true);
    setMessage('');
    try {
      await deactivateUser(token, id);
      setUsers(users => users.filter(u => u.id !== id));
      setMessage('User deleted');
    } catch (e) {
      setMessage('Failed to delete user');
    }
    setLoading(false);
  }

  return (
    <div className='form-container' style={{marginTop:'30px'}}>
    <div className="list-container">
      <h2>Admin Dashboard</h2>
      {loading && <div className="loading">Loading...</div>}
      {message && <div className="form-message">{message}</div>}
      <div className="dashboard-stats">
        <div>Total Users: <b>{totalUsers}</b></div>
      </div>
      <h3>Manage Users</h3>
      <table className="list-table">
        <thead>
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Role</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {users.map(u => (
            <tr key={u.id}>
              <td>{u.id}</td>
              <td>{u.name}</td>
              <td>{u.email}</td>
              <td>
                <select value={u.role} onChange={e => handleRoleChange(u.id, e.target.value)}>
                  <option value="ROLE_USER">User</option>
                  <option value="ROLE_ADMIN">Admin</option>
                </select>
              </td>
              <td>
                <button className="danger-btn" onClick={() => handleDelete(u.id)} style={{marginLeft: 8}}>
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
    </div>
  )
}
