import { useContext, useEffect, useState } from 'react'
import { toast } from 'react-toastify'
import { fetchSubscriptions, deleteSubscription } from '../api/subscriptions'
import { AuthContext } from '../contexts/AuthContext'
import '../styles/Lists.css'

export default function SubscriptionList({ onSelect, onEdit }) {
  const { token } = useContext(AuthContext)
  const [subscriptions, setSubscriptions] = useState([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState(null)

  const loadSubscriptions = async () => {
    setIsLoading(true)
    try {
      const response = await fetchSubscriptions(token)
      console.log("Loaded subscriptions:", response.data.data);
      setSubscriptions(response.data.data || [])
      setError(null)
    } catch (err) {
      setError('Failed to load subscriptions. Please try again.')
      console.error('Error loading subscriptions:', err)
    } finally {
      setIsLoading(false)
    }
  }

  useEffect(() => {
    loadSubscriptions()
  }, [token])

  const handleDelete = async (id) => {
    if (!window.confirm('Are you sure you want to delete this subscription?')) {
      return
    }
    
    try {
      await deleteSubscription(id, token)
      toast.success('Subscription deleted successfully')
      loadSubscriptions()
    } catch (err) {
      toast.error('Failed to delete subscription')
      console.error('Error deleting subscription:', err)
    }
  }

  if (isLoading) {
    return <div className="loading-indicator">Loading subscriptions...</div>
  }

  if (error) {
    return <div className="error-message">{error}</div>
  }

  if (subscriptions.length === 0) {
    return (
      <div className="empty-state">
        <div className="empty-icon">📋</div>
        <div className="message">No subscriptions found</div>
        <p>Click the "Add Subscription" button to get started.</p>
      </div>
    )
  }

  return (
    <div className="list-container">
      <table className="list-table">
        <thead>
          <tr>
            <th>Subscription</th>
            <th>Provider</th>
            <th>Category</th>
            <th>Amount</th>
            <th>Frequency</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {subscriptions.map((subscription) => (
            <tr key={subscription.id}>
              <td>{subscription.subscriptionName}</td>
              <td>{subscription.providerName}</td>
              <td>{subscription.category}</td>
              <td>
                {subscription.amount} {subscription.currency}
              </td>
              <td>{subscription.frequency}</td>
              <td>
                <span className={`status ${subscription.active ? 'active' : 'inactive'}`}>
                  {subscription.active ? 'Active' : 'Inactive'}
                </span>
              </td>
              <td className="actions">
                <button
                  className="action-button secondary"
                  onClick={() => onSelect(subscription.id)}
                  title="View Payments"
                >
                  Payments
                </button>
                <button 
                  className="action-button primary"
                  onClick={() => onEdit(subscription)}
                  title="Edit Subscription"
                >
                  Edit
                </button>
                <button
                  className="action-button danger"
                  onClick={() => handleDelete(subscription.id)}
                  title="Delete Subscription"
                >
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
