import { useContext } from 'react'
import { Navigate, Outlet } from 'react-router-dom'
import { AuthContext } from '../contexts/AuthContext'

export default function ProtectedRoute({ allowedRoles }) {
  const { token, user } = useContext(AuthContext)

  if (!token) {
    return <Navigate to="/welcome" replace />
  }

  if (allowedRoles && user && !allowedRoles.includes(user.role)) {
    if (user.role === 'ROLE_ADMIN') return <Navigate to="/admin" replace />
    if (user.role === 'ROLE_USER') return <Navigate to="/dashboard" replace />
    return <Navigate to="/welcome" replace />
  }

  return <Outlet />
}