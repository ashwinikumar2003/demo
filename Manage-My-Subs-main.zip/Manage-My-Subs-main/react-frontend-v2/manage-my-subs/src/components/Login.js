import { useState, useContext } from 'react'
import { Link, Navigate, useNavigate } from 'react-router-dom'
import { toast } from 'react-toastify'
import { AuthContext } from '../contexts/AuthContext'
import { FaEnvelope, FaLock} from 'react-icons/fa'
import '../styles/AuthForms.css'

export default function Login() {
  const [email, setEmail]       = useState('')
  const [password, setPassword] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const [errors, setErrors]      = useState({})
  
  const { login, user } = useContext(AuthContext)
  const navigate = useNavigate()

  if (user) {
    return <Navigate to="/dashboard" replace />
  }

  const validateForm = () => {
    const newErrors = {}
    
    if (!email.trim()) {
      newErrors.email = 'Email is required'
    } else if (!/\S+@\S+\.\S+/.test(email)) {
      newErrors.email = 'Email is invalid'
    }
    
    if (!password) {
      newErrors.password = 'Password is required'
    } else if (password.length < 6) {
      newErrors.password = 'Password must be at least 6 characters'
    }
    
    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    
    if (!validateForm()) return
    
    setIsLoading(true)
    
    try {
      await login({ email, password })
      toast.success('Login successful!')
      navigate('/dashboard')
    } catch (error) {
      let errorMessage = 'Login failed'
      
      if (error.response) {
        errorMessage = error.response.data.message || errorMessage
      }
      
      toast.error(errorMessage)
      setIsLoading(false)
    }
  }

  return (
    <div className="auth-container">
      <div className="auth-form-container">
        <h2>Log In</h2>
        <form onSubmit={handleSubmit} className="auth-form">
          <div className="form-group">
            {/* <label htmlFor="email">Email</label> */}
            <div style={{ display: 'flex', alignItems: 'center' }}>
              <FaEnvelope style={{ marginRight: 8, color: '#333' }} />
              <input
                type="email"
                id="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="your@email.com"
                className={errors.email ? 'input-error' : ''}
                style={{ flexGrow: 1 }}
              />
            </div>
            {errors.email && <div className="error-message">{errors.email}</div>}
          </div>
          
          <div className="form-group">
            {/* <label htmlFor="password">Password</label> */}
            <div style={{ display: 'flex', alignItems: 'center' }}>
              <FaLock style={{ marginRight: 8, color: '#333' }} />
              <input
                type="password"
                id="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Password"
                className={errors.password ? 'input-error' : ''}
                style={{ flexGrow: 1 }}
              />
            </div>
            {errors.password && <div className="error-message">{errors.password}</div>}
          </div>
          
          <button 
            type="submit" 
            className="auth-button" 
            disabled={isLoading || !email || !password || Object.keys(errors).length > 0}
          >
            {isLoading ? 'Logging in...' : 'Log In'}
          </button>
        </form>
        
        <div className="auth-links">
          <p>
            <span>Don't have an account? <Link to="/register"><button style={{cursor:"pointer", borderRadius:"5px", color:"white", background:"purple", height:"30px"}}>Register</button></Link></span>
          </p>
        </div>
      </div>
    </div>
  )
}
