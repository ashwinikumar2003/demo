import { useState, useEffect, useContext } from 'react'
import { toast } from 'react-toastify'
import { createSubscription, updateSubscription } from '../api/subscriptions'
import { AuthContext } from '../contexts/AuthContext'
import '../styles/Forms.css'

const initialForm = {
  subscriptionName: '',
  providerName: '',
  category: 'ENTERTAINMENT',
  startDate: new Date().toISOString().substr(0, 10),
  amount: '',
  currency: 'INR',
  frequency: 'MONTHLY',
  active: true
}

export default function SubscriptionForm({ subscription, onSave, onCancel, isEditing }) {
  const { token } = useContext(AuthContext)
  const [form, setForm] = useState(initialForm)
  const [errors, setErrors] = useState({})
  const [isLoading, setIsLoading] = useState(false)

  useEffect(() => {
    if (isEditing && subscription) {
      console.log("Editing subscription:", subscription);
      setForm({
        ...subscription,
        startDate: subscription.startDate ? 
          new Date(subscription.startDate).toISOString().substr(0, 10) : 
          new Date().toISOString().substr(0, 10)
      })
    }
  }, [isEditing, subscription])

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target
    setForm((prev) => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }))
    
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: null }))
    }
  }

  const validateForm = () => {
    const newErrors = {}
    
    if (!form.subscriptionName.trim()) {
      newErrors.subscriptionName = 'Subscription name is required'
    }
    
    if (!form.providerName.trim()) {
      newErrors.providerName = 'Provider name is required'
    }
    
    if (!form.startDate) {
      newErrors.startDate = 'Start date is required'
    }
    
    if (!form.amount || isNaN(parseFloat(form.amount)) || parseFloat(form.amount) <= 0) {
      newErrors.amount = 'Please enter a valid amount'
    }
    
    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    
    if (!validateForm()) {
      toast.error('Please correct the errors in the form')
      return
    }
    
    setIsLoading(true)
    
    try {
      const subscriptionData = {
        ...form,
        amount: parseFloat(form.amount)
      }
      
      if (isEditing) {
        console.log("Updating subscription:", subscriptionData);
        await updateSubscription(subscription.id, subscriptionData, token)
        toast.success('Subscription updated successfully')
      } else {
        await createSubscription(subscriptionData, token)
        toast.success('Subscription created successfully')
      }
      
      setForm(initialForm)
      onSave()
    } catch (err) {
      console.error("Error updating subscription:", err);
      let errorMessage = isEditing ? 
        'Failed to update subscription' : 
        'Failed to create subscription'
      
      if (err.response?.data?.message) {
        errorMessage = err.response.data.message
      }
      
      toast.error(errorMessage)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="form-container">
      <form onSubmit={handleSubmit} className="data-form">
        <div className="form-group">
          <label htmlFor="subscriptionName">Subscription Name</label>
          <input
            type="text"
            id="subscriptionName"
            name="subscriptionName"
            value={form.subscriptionName}
            onChange={handleInputChange}
            placeholder="Netflix, Spotify, etc."
            className={errors.subscriptionName ? 'input-error' : ''}
          />
          {errors.subscriptionName && (
            <div className="error-message">{errors.subscriptionName}</div>
          )}
        </div>

        <div className="form-group">
          <label htmlFor="providerName">Provider</label>
          <input
            type="text"
            id="providerName"
            name="providerName"
            value={form.providerName}
            onChange={handleInputChange}
            placeholder="Company providing the service"
            className={errors.providerName ? 'input-error' : ''}
          />
          {errors.providerName && (
            <div className="error-message">{errors.providerName}</div>
          )}
        </div>

        <div className="form-row">
          <div className="form-group">
            <label htmlFor="category">Category</label>
            <select
              id="category"
              name="category"
              value={form.category}
              onChange={handleInputChange}
            >
              <option value="ENTERTAINMENT">Entertainment</option>
              <option value="SOFTWARE">Software</option>
              <option value="HEALTH">Health</option>
              <option value="EDUCATION">Education</option>
              <option value="PRODUCTIVITY">Productivity</option>
              <option value="OTHER">Other</option>
            </select>
          </div>

          <div className="form-group">
            <label htmlFor="startDate">Start Date</label>
            <input
              type="date"
              id="startDate"
              name="startDate"
              value={form.startDate}
              onChange={handleInputChange}
              className={errors.startDate ? 'input-error' : ''}
            />
            {errors.startDate && (
              <div className="error-message">{errors.startDate}</div>
            )}
          </div>
        </div>

        <div className="form-row">
          <div className="form-group">
            <label htmlFor="amount">Amount</label>
            <input
              type="number"
              id="amount"
              name="amount"
              value={form.amount}
              onChange={handleInputChange}
              placeholder="0.00"
              min="0"
              step="0.01"
              className={errors.amount ? 'input-error' : ''}
            />
            {errors.amount && (
              <div className="error-message">{errors.amount}</div>
            )}
          </div>

          <div className="form-group">
            <label htmlFor="currency">Currency</label>
            <select
              id="currency"
              name="currency"
              value={form.currency}
              onChange={handleInputChange}
            >
              <option value="USD">USD</option>
              <option value="EUR">EUR</option>
              <option value="INR">INR</option>
              <option value="JPY">JPY</option>
            </select>
          </div>
        </div>

        <div className="form-row">
          <div className="form-group">
            <label htmlFor="frequency">Billing Frequency</label>
            <select
              id="frequency"
              name="frequency"
              value={form.frequency}
              onChange={handleInputChange}
            >
              <option value="WEEKLY">Weekly</option>
              <option value="MONTHLY">Monthly</option>
              <option value="QUARTERLY">Quarterly</option>
              <option value="YEARLY">Yearly</option>
            </select>
          </div>

          <div className="form-group checkbox-group">
            <label htmlFor="active" className="checkbox-label">
              <input
                type="checkbox"
                id="active"
                name="active"
                checked={form.active}
                onChange={handleInputChange}
              />
              <span>Active Subscription</span>
            </label>
          </div>
        </div>

        <div className="form-actions">
          {onCancel && (
            <button 
              type="button" 
              onClick={onCancel} 
              className="button secondary"
              disabled={isLoading}
            >
              Cancel
            </button>
          )}
          <button 
            type="submit" 
            className="button primary"
            disabled={isLoading}
          >
            {isLoading 
              ? (isEditing ? 'Updating...' : 'Creating...') 
              : (isEditing ? 'Update Subscription' : 'Create Subscription')
            }
          </button>
        </div>
      </form>
    </div>
  )
}