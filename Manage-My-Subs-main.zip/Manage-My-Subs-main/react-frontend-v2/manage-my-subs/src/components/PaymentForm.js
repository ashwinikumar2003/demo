import { useState, useContext, useEffect } from 'react'
import { createPayment } from '../api/payment'
import { fetchSubscriptions } from '../api/subscriptions'
import { toast } from 'react-toastify'
import { AuthContext } from '../contexts/AuthContext'
import '../styles/Forms.css'

const initialForm = {
  subscriptionId: '',
  amount: '',
  currency: 'USD',
  paymentDate: new Date().toISOString().substr(0, 10),
  paymentMethod: 'CREDIT_CARD',
  status: 'SUCCESSFUL',
  notes: ''
}

export default function PaymentForm({ subscriptionId, onSave, onCancel }) {
  const { token } = useContext(AuthContext)
  const [form, setForm] = useState({
    ...initialForm,
    subscriptionId: subscriptionId || ''
  })
  const [errors, setErrors] = useState({})
  const [isLoading, setIsLoading] = useState(false)
  const [subscriptions, setSubscriptions] = useState([])

  useEffect(() => {
    if (!subscriptionId) {
      fetchUserSubscriptions()
    }
  }, [])

  const fetchUserSubscriptions = async () => {
    try {
      const response = await fetchSubscriptions(token)
      setSubscriptions(response.data.data || [])
    } catch (error) {
      console.error('Failed to fetch subscriptions:', error)
    }
  }

  const handleInputChange = (e) => {
    const { name, value } = e.target
    setForm(prev => ({
      ...prev,
      [name]: value
    }))
    
    // Clear error for this field when user types
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: null }))
    }
  }

  const validateForm = () => {
    const newErrors = {}
    
    if (!subscriptionId && !form.subscriptionId) {
      newErrors.subscriptionId = 'Please select a subscription'
    }
    
    if (!form.amount || isNaN(parseFloat(form.amount)) || parseFloat(form.amount) <= 0) {
      newErrors.amount = 'Please enter a valid amount'
    }
    
    if (!form.paymentDate) {
      newErrors.paymentDate = 'Payment date is required'
    }
    
    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    
    if (!validateForm()) {
      toast.error('Please correct the errors in the form')
      return
    }
    
    setIsLoading(true)
    
    try {
      // Format the request
      const paymentData = {
        ...form,
        subscriptionId: parseInt(subscriptionId || form.subscriptionId),
        amount: parseFloat(form.amount)
      }
      
      await createPayment(paymentData, token)
      toast.success('Payment recorded successfully')
      
      // Reset form and notify parent
      setForm({
        ...initialForm,
        subscriptionId: subscriptionId || ''
      })
      onSave()
    } catch (err) {
      let errorMessage = 'Failed to record payment'
      
      if (err.response?.data?.message) {
        errorMessage = err.response.data.message
      }
      
      toast.error(errorMessage)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="form-container">
      <form onSubmit={handleSubmit} className="data-form">
        {!subscriptionId && (
          <div className="form-group">
            <label htmlFor="subscriptionId">Subscription</label>
            <select
              id="subscriptionId"
              name="subscriptionId"
              value={form.subscriptionId}
              onChange={handleInputChange}
              className={errors.subscriptionId ? 'input-error' : ''}
            >
              <option value="">Select a subscription</option>
              {subscriptions.map(sub => (
                <option key={sub.id} value={sub.id}>
                  {sub.subscriptionName} - {sub.providerName}
                </option>
              ))}
            </select>
            {errors.subscriptionId && (
              <div className="error-message">{errors.subscriptionId}</div>
            )}
          </div>
        )}
        <div className="form-row">
          <div className="form-group">
            <label htmlFor="amount">Amount</label>
            <input
              type="number"
              id="amount"
              name="amount"
              value={form.amount}
              onChange={handleInputChange}
              placeholder="0.00"
              min="0"
              step="0.01"
              className={errors.amount ? 'input-error' : ''}
            />
            {errors.amount && (
              <div className="error-message">{errors.amount}</div>
            )}
          </div>

          <div className="form-group">
            <label htmlFor="currency">Currency</label>
            <select
              id="currency"
              name="currency"
              value={form.currency}
              onChange={handleInputChange}
            >
              <option value="USD">USD</option>
              <option value="EUR">EUR</option>
              <option value="GBP">GBP</option>
              <option value="INR">INR</option>
              <option value="JPY">JPY</option>
              <option value="CAD">CAD</option>
              <option value="AUD">AUD</option>
            </select>
          </div>
        </div>

        <div className="form-row">
          <div className="form-group">
            <label htmlFor="paymentDate">Payment Date</label>
            <input
              type="date"
              id="paymentDate"
              name="paymentDate"
              value={form.paymentDate}
              onChange={handleInputChange}
              className={errors.paymentDate ? 'input-error' : ''}
            />
            {errors.paymentDate && (
              <div className="error-message">{errors.paymentDate}</div>
            )}
          </div>

          <div className="form-group">
            <label htmlFor="paymentMethod">Payment Method</label>
            <select
              id="paymentMethod"
              name="paymentMethod"
              value={form.paymentMethod}
              onChange={handleInputChange}
            >
              <option value="CREDIT_CARD">Credit Card</option>
              <option value="DEBIT_CARD">Debit Card</option>
              <option value="BANK_TRANSFER">Bank Transfer</option>
              <option value="PAYPAL">PayPal</option>
              <option value="CASH">Cash</option>
              <option value="OTHER">Other</option>
            </select>
          </div>
        </div>

        <div className="form-group">
          <label htmlFor="status">Payment Status</label>
          <select
            id="status"
            name="status"
            value={form.status}
            onChange={handleInputChange}
          >
            <option value="SUCCESSFUL">Successful</option>
            <option value="PENDING">Pending</option>
            <option value="FAILED">Failed</option>
            <option value="REFUNDED">Refunded</option>
          </select>
        </div>

        <div className="form-group">
          <label htmlFor="notes">Notes (Optional)</label>
          <textarea
            id="notes"
            name="notes"
            value={form.notes}
            onChange={handleInputChange}
            placeholder="Add any additional information about this payment"
            rows="3"
          ></textarea>
        </div>

        <div className="form-actions">
          {onCancel && (
            <button 
              type="button" 
              onClick={onCancel} 
              className="button secondary"
              disabled={isLoading}
            >
              Cancel
            </button>
          )}
          <button 
            type="submit" 
            className="button primary"
            disabled={isLoading}
          >
            {isLoading ? 'Recording Payment...' : 'Record Payment'}
          </button>
        </div>
      </form>
    </div>
  )
}
