import { useState, useContext, useEffect } from 'react'
import { toast } from 'react-toastify'
import { AuthContext } from '../contexts/AuthContext'
import SubscriptionList from './SubscriptionList'
import SubscriptionForm from './SubscriptionForm'
import PaymentList from './PaymentList'
import PaymentForm from './PaymentForm'
import AnalyticsCards from './AnalyticsCards'
import '../styles/Dashboard.css'

export default function Dashboard() {
  const { user } = useContext(AuthContext)
  const [selectedSubscriptionId, setSelectedSubscriptionId] = useState(null)
  const [view, setView] = useState('subscriptions')
  const [activeTab, setActiveTab] = useState('subscriptions')
  const [subscriptionToEdit, setSubscriptionToEdit] = useState(null)
  
  console.log(user);
  useEffect(() => {
    if (selectedSubscriptionId) {
      setView('subscriptionPayments')
      setActiveTab('subscriptionPayments')
    }
  }, [selectedSubscriptionId])
  
  const handleTabClick = (tab) => {
    setActiveTab(tab)
    setView(tab)
    if (tab === 'subscriptions') {
      setSelectedSubscriptionId(null)
      setSubscriptionToEdit(null)
    }
  }
  
  const handleAddSubscription = () => {
    setSubscriptionToEdit(null)
    setView('addSubscription')
  }
  
  const handleEditSubscription = (subscription) => {
    setSubscriptionToEdit(subscription)
    setView('editSubscription')
  }
  
  const handleAddPayment = () => {
    if (!selectedSubscriptionId && view === 'subscriptionPayments') {
      toast.warning('Please select a subscription first')
      return
    }
    setView('addPayment')
  }
  
  const handleFormCancel = () => {
    setView(activeTab)
    setSubscriptionToEdit(null)
  }
  
  const handleFormSuccess = () => {
    setView(activeTab)
    setSubscriptionToEdit(null)
    toast.success(
      view === 'addSubscription' 
        ? 'Subscription added successfully!' 
        : view === 'editSubscription'
          ? 'Subscription updated successfully!'
          : 'Payment added successfully!'
    )
  }

  return (
    <div className="dashboard-container">
      <div className="dashboard-header">
        <h1>Welcome, {user?.email.split("@")[0].replace(/^./, c => c.toUpperCase()) || 'User'}</h1>
        <AnalyticsCards updateAt={view}/>
        
        <div className="dashboard-tabs">
          <button 
            className={`tab-button ${activeTab === 'subscriptions' ? 'active' : ''}`}
            onClick={() => handleTabClick('subscriptions')}
          >
            Subscriptions
          </button>
          <button 
            className={`tab-button ${activeTab === 'subscriptionPayments' ? 'active' : ''}`}
            onClick={() => {
              if (selectedSubscriptionId) {
                handleTabClick('subscriptionPayments')
              } else {
                toast.info('Please select a subscription first')
              }
            }}
            disabled={!selectedSubscriptionId}
          >
            Subscription Payments
          </button>
          <button 
            className={`tab-button ${activeTab === 'allPayments' ? 'active' : ''}`}
            onClick={() => handleTabClick('allPayments')}
          >
            All Payments
          </button>
        </div>
      </div>
      
      <div className="dashboard-content">
        {view === 'subscriptions' && (
          <div className="subscriptions-view">
            <div className="view-header">
              <h2>Your Subscriptions</h2>
              <button 
                className="action-button"
                onClick={handleAddSubscription}
              >
                + Add Subscription
              </button>
            </div>
            <SubscriptionList 
              onSelect={setSelectedSubscriptionId} 
              onEdit={handleEditSubscription}
            />
          </div>
        )}
        
        {view === 'addSubscription' && (
          <div className="form-view">
            <div className="view-header">
              <h2>Add New Subscription</h2>
              <button 
                className="action-button secondary"
                onClick={handleFormCancel}
              >
                Cancel
              </button>
            </div>
            <SubscriptionForm 
              onSave={handleFormSuccess} 
              onCancel={handleFormCancel}
            />
          </div>
        )}
        
        {view === 'editSubscription' && subscriptionToEdit && (
          <div className="form-view">
            <div className="view-header">
              <h2>Edit Subscription</h2>
              <button 
                className="action-button secondary"
                onClick={handleFormCancel}
              >
                Cancel
              </button>
            </div>
            <SubscriptionForm 
              subscription={subscriptionToEdit}
              onSave={handleFormSuccess} 
              onCancel={handleFormCancel}
              isEditing={true}
            />
          </div>
        )}
        
        {view === 'subscriptionPayments' && selectedSubscriptionId && (
          <div className="payments-view">
            <div className="view-header">
              <h2>Payments for Subscription #{selectedSubscriptionId}</h2>
              <div className="header-actions">
                <button 
                  className="action-button"
                  onClick={handleAddPayment}
                >
                  + Add Payment
                </button>
                <button 
                  className="action-button secondary"
                  onClick={() => {
                    setSelectedSubscriptionId(null)
                    setView('subscriptions')
                    setActiveTab('subscriptions')
                  }}
                >
                  Back to Subscriptions
                </button>
              </div>
            </div>
            <PaymentList subscriptionId={selectedSubscriptionId} />
          </div>
        )}
        
        {view === 'allPayments' && (
          <div className="payments-view">
            <div className="view-header">
              <h2>All Your Payments</h2>
              <div className="header-actions">
                <button 
                  className="action-button"
                  onClick={handleAddPayment}
                >
                  + Add Payment
                </button>
              </div>
            </div>
            <PaymentList />
          </div>
        )}
        
        {view === 'addPayment' && (
          <div className="form-view">
            <div className="view-header">
              <h2>Add New Payment</h2>
              <button 
                className="action-button secondary"
                onClick={handleFormCancel}
              >
                Cancel
              </button>
            </div>
            <PaymentForm 
              subscriptionId={selectedSubscriptionId}
              onSave={handleFormSuccess}
              onCancel={handleFormCancel}
            />
          </div>
        )}
      </div>
    </div>
  )
}