import axios from 'axios';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:8080/api/users';

export async function getProfile(token) {
  const res = await axios.get(`${API_URL}/me`, {
    headers: { Authorization: `Bearer ${token}` }
  });
  return res.data.data;
}

export async function updateProfile(token, update) {
  const res = await axios.put(`${API_URL}/me`, update, {
    headers: { Authorization: `Bearer ${token}` }
  });
  return res.data.data;
}

export async function updatePassword(token, passwordData) {
  await axios.put(`${API_URL}/me/password`, passwordData, {
    headers: { Authorization: `Bearer ${token}` }
  });
}
