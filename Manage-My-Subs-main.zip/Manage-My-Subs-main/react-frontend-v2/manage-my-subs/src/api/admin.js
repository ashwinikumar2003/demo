import axios from 'axios';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:8080/api/users';

export async function getAllUsers(token) {
  const res = await axios.get(`${API_URL}`, {
    headers: { Authorization: `Bearer ${token}` }
  });
  return res.data.data;
}

export async function deactivateUser(token, userId) {
  await axios.delete(`${API_URL}/${userId}`, {
    headers: { Authorization: `Bearer ${token}` }
  });
}

export async function updateUserRole(token, userId, role) {
  const res = await axios.put(`${API_URL}/${userId}/role?role=${role}`, {}, {
    headers: { Authorization: `Bearer ${token}` }
  });
  return res.data.data;
}
