import axios from 'axios'

const BASE_URL = 'http://localhost:8080/api/alerts'

export const getUserAlerts = async (token) => {
  const res = await axios.get(BASE_URL, {
    headers: { Authorization: `Bearer ${token}` }
  });
  return res.data.data
}

export const markAlertAsRead = async (alertId, token) => {
  const res = await axios.put(`${BASE_URL}/${alertId}/read`, {}, {
    headers: { Authorization: `Bearer ${token}` }
  });
  return res.data.data
}