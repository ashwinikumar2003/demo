import axios from 'axios'

const BASE = 'http://localhost:8080/api/subscriptions'

export function fetchSubscriptions(token) {
  return axios.get(BASE, { headers: { Authorization: `Bearer ${token}` } })
}

export function createSubscription(data, token) {
  return axios.post(BASE, data, { headers: { Authorization: `Bearer ${token}` } })
}

export function updateSubscription(id, data, token) {
  return axios.put(`${BASE}/${id}`, data, { headers: { Authorization: `Bearer ${token}` } })
}

export function deleteSubscription(id, token) {
  return axios.delete(`${BASE}/${id}`, { headers: { Authorization: `Bearer ${token}` } })
}
