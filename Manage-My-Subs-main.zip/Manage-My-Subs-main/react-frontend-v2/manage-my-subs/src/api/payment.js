import axios from 'axios'

const BASE_URL = 'http://localhost:8080/api/payments'

export const getPaymentsByUser = async (token) => {
  const res = await axios.get(BASE_URL, {
    headers: { Authorization: `Bearer ${token}` }
  });
  return res.data.data
}

export const getPaymentsBySubscription = async (subscriptionId, token) => {
  const res = await axios.get(`${BASE_URL}/subscription/${subscriptionId}`, {
    headers: { Authorization: `Bearer ${token}` }
  });
  return res.data.data
}

export const createPayment = async (paymentData, token) => {
  const res = await axios.post(BASE_URL, paymentData, {
    headers: { Authorization: `Bearer ${token}` }
  })
  return res.data.data
}