import axios from 'axios'

const BASE = 'http://localhost:8080/api/auth'

export function register({ name, email, password, role }) {
  return axios.post(`${BASE}/register`, { name, email, password, role })
}

export function login({ email, password }) {
  return axios.post(`${BASE}/login`, { email, password })
}
