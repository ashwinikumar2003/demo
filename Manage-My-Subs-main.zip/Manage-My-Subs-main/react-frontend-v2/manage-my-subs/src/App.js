import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { ToastContainer } from 'react-toastify'
import 'react-toastify/dist/ReactToastify.css'
import { AuthProvider, useAuth } from './contexts/AuthContext'
import Layout from './components/Layout'
import Login from './components/Login'
import Register from './components/Register'
import Dashboard from './components/Dashboard'
import Welcome from './components/Welcome'
import ProtectedRoute from './components/ProtectedRoute'
import Profile from './components/Profile'
import AdminDashboard from './components/AdminDashboard'
import './App.css'

function RoleRedirect() {
  const { user } = useAuth()
  if (!user) return <Navigate to="/welcome" replace />
  return user.role === 'ROLE_ADMIN'
    ? <Navigate to="/admin" replace />
    : <Navigate to="/dashboard" replace />
}

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <ToastContainer position="top-right" autoClose={3000} />
        <Layout>
          <Routes>
            <Route path="/welcome" element={<Welcome />} />
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />

            <Route element={<ProtectedRoute allowedRoles={['ROLE_USER']} />}> 
              <Route path="/dashboard" element={<Dashboard />} />
            </Route>

            <Route element={<ProtectedRoute allowedRoles={['ROLE_ADMIN']} />}> 
              <Route path="/admin" element={<AdminDashboard />} />
            </Route>

            <Route element={<ProtectedRoute allowedRoles={['ROLE_USER', 'ROLE_ADMIN']} />}> 
              <Route path="/profile" element={<Profile />} />
              <Route path="/" element={<RoleRedirect />} />
            </Route>

            <Route path="*" element={<Navigate to="/welcome" replace />} />
          </Routes>
        </Layout>
      </BrowserRouter>
    </AuthProvider>
  )
}