package com.api_gateway.security;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;
import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.security.Key;
import java.util.Date;

@Component
@Slf4j
public class JwtUtil {
    @Value("${jwt.secret}") 
    private String jwtSecret;
    
    @Value("${jwt.expiration}") 
    private long jwtExpirationMs;
    
    private Key signingKey;

    @PostConstruct
    public void init() {
        try {
            log.info("Initializing JWT signing key with secret of length: {}", jwtSecret.length());
            byte[] keyBytes = Decoders.BASE64.decode(jwtSecret);
            signingKey = Keys.hmacShaKeyFor(keyBytes);
            log.info("JWT signing key initialized successfully");
        } catch (Exception e) {
            log.error("Error initializing JWT signing key", e);
            throw new RuntimeException("Failed to initialize JWT signing key", e);
        }
    }
    
    public boolean validateToken(String token) {
        try {
            Jwts.parserBuilder()
                    .setSigningKey(signingKey)
                    .build()
                    .parseClaimsJws(token);
            return true;
        } catch (JwtException | IllegalArgumentException ex) {
            log.error("Invalid JWT token: {}", ex.getMessage());
            return false;
        }
    }
    
    public Claims extractAllClaims(String token) {
        return Jwts.parserBuilder()
                .setSigningKey(signingKey)
                .build()
                .parseClaimsJws(token)
                .getBody();
    }
    
    public String extractUsername(String token) {
        return extractAllClaims(token).getSubject();
    }
    
    public String extractRole(String token) {
        return extractAllClaims(token).get("role", String.class);
    }
    
    public boolean isTokenExpired(String token) {
        Date expiration = extractAllClaims(token).getExpiration();
        return expiration.before(new Date());
    }
}