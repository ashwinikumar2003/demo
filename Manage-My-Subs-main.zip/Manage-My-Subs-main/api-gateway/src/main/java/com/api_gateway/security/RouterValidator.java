package com.api_gateway.security;

import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.function.Predicate;

@Component
public class RouterValidator {
    // List of endpoints that don't require authentication
    public static final List<String> openApiEndpoints = List.of(
            "/api/auth/register",
            "/api/auth/login",
            "/eureka",
            "/actuator",
            "/actuator/**"
    );

    // Predicate to determine if the request is to be secured
    public Predicate<ServerHttpRequest> isSecured = 
            request -> openApiEndpoints
                    .stream()
                    .noneMatch(uri -> request.getURI().getPath().contains(uri));
} 