package com.user_service.controller;

import com.user_service.dto.*;
import com.user_service.service.UserService;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@Slf4j
@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthController {

    private final UserService userService;

    @PostMapping("/register")
    public ResponseEntity<ApiResponse<UserResponseDTO>> register(@Valid @RequestBody UserRegistrationDTO dto) {
        log.info("registering user");
        return ResponseEntity.ok(
                new ApiResponse<>(HttpStatus.OK, "User registered", userService.registerUser(dto))
        );
    }

    @PostMapping("/login")
    public ResponseEntity<ApiResponse<LoginResponseDTO>> login(@Valid @RequestBody LoginRequestDTO dto) {
        log.info("signing in user");
        return ResponseEntity.ok(
                new ApiResponse<>(HttpStatus.OK, "Login successful", userService.loginUser(dto))
        );
    }
}