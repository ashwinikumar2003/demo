package com.user_service.controller;

import com.user_service.dto.ApiResponse;
import com.user_service.dto.UserResponseDTO;
import com.user_service.dto.UserProfileUpdateDTO;
import com.user_service.dto.UserPasswordUpdateDTO;
import com.user_service.service.UserService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/users")
@RequiredArgsConstructor
public class UserController {

    private final UserService userService;

    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    @GetMapping
    public ResponseEntity<ApiResponse<List<UserResponseDTO>>> getAllUsers() {
        return ResponseEntity.ok(
                new ApiResponse<>(HttpStatus.OK, "All users", userService.getAllUsers())
        );
    }

    @PreAuthorize("hasAnyAuthority('ROLE_ADMIN', 'ROLE_USER')")
    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<UserResponseDTO>> getUserById(@PathVariable Long id) {
        return ResponseEntity.ok(
                new ApiResponse<>(HttpStatus.OK, "User details", userService.getUserById(id))
        );
    }

    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse<Void>> deleteUser(@PathVariable Long id) {
        userService.deleteUser(id);
        return ResponseEntity.ok(
                new ApiResponse<>(HttpStatus.OK, "User deleted", null)
        );
    }
    
    @GetMapping("/validate")
    public ResponseEntity<Boolean> validateUser() {
        return ResponseEntity.ok(true);
    }

    @PreAuthorize("hasAnyAuthority('ROLE_ADMIN', 'ROLE_USER')")
    @GetMapping("/me")
    public ResponseEntity<ApiResponse<UserResponseDTO>> getCurrentUserProfile(HttpServletRequest request) {
        Long userId = userService.extractUserIdFromToken(request.getHeader("Authorization"));
        return ResponseEntity.ok(
            new ApiResponse<>(HttpStatus.OK, "Profile fetched", userService.getCurrentUserProfile(userId))
        );
    }

    @PreAuthorize("hasAnyAuthority('ROLE_ADMIN', 'ROLE_USER')")
    @PutMapping("/me")
    public ResponseEntity<ApiResponse<UserResponseDTO>> updateUserProfile(HttpServletRequest request, 
                                                                @Valid @RequestBody UserProfileUpdateDTO updateDTO) {
        Long userId = userService.extractUserIdFromToken(request.getHeader("Authorization"));
        return ResponseEntity.ok(
            new ApiResponse<>(HttpStatus.OK, "Profile updated", userService.updateUserProfile(userId, updateDTO))
        );
    }

    @PreAuthorize("hasAnyAuthority('ROLE_ADMIN', 'ROLE_USER')")
    @PutMapping("/me/password")
    public ResponseEntity<ApiResponse<Void>> updateUserPassword(HttpServletRequest request,
                                                               @Valid @RequestBody UserPasswordUpdateDTO passwordDTO) {
        Long userId = userService.extractUserIdFromToken(request.getHeader("Authorization"));
        userService.updateUserPassword(userId, passwordDTO);
        return ResponseEntity.ok(new ApiResponse<>(HttpStatus.OK, "Password updated", null));
    }

    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    @PutMapping("/{id}/role")
    public ResponseEntity<ApiResponse<UserResponseDTO>> updateUserRole(@PathVariable Long id, @RequestParam @NotBlank String role) {
        return ResponseEntity.ok(
            new ApiResponse<>(HttpStatus.OK, "Role updated", userService.updateUserRole(id, role))
        );
    }
}