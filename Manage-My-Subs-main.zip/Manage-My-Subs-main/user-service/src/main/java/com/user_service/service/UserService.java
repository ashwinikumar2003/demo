package com.user_service.service;

import com.user_service.dto.LoginRequestDTO;
import com.user_service.dto.LoginResponseDTO;
import com.user_service.dto.UserRegistrationDTO;
import com.user_service.dto.UserResponseDTO;
import com.user_service.dto.UserProfileUpdateDTO;
import com.user_service.dto.UserPasswordUpdateDTO;

import java.util.List;

public interface UserService {
    UserResponseDTO registerUser(UserRegistrationDTO userDTO);
    LoginResponseDTO loginUser(LoginRequestDTO loginDTO);
    List<UserResponseDTO> getAllUsers();
    UserResponseDTO getUserById(Long id);
    void deleteUser(Long id);

    UserResponseDTO getCurrentUserProfile(Long userId);
    UserResponseDTO updateUserProfile(Long userId, UserProfileUpdateDTO updateDTO);
    void updateUserPassword(Long userId, UserPasswordUpdateDTO passwordDTO);
    Long extractUserIdFromToken(String authHeader);
    UserResponseDTO updateUserRole(Long id, String role);
}