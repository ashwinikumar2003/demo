package com.user_service.service;

import com.user_service.config.JwtUtil;
import com.user_service.dto.LoginRequestDTO;
import com.user_service.dto.LoginResponseDTO;
import com.user_service.dto.UserRegistrationDTO;
import com.user_service.dto.UserResponseDTO;
import com.user_service.dto.UserPasswordUpdateDTO;
import com.user_service.dto.UserProfileUpdateDTO;
import com.user_service.entity.Role;
import com.user_service.entity.User;
import com.user_service.exception.CustomException;
import com.user_service.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtil jwtUtil;

    @Override
    public UserResponseDTO registerUser(UserRegistrationDTO userDTO) {
        log.info("registerUser called");
        if (userRepository.existsByEmail(userDTO.getEmail())) {
            throw new CustomException("Email already exists");
        }

        User user = User.builder()
                .name(userDTO.getName())
                .email(userDTO.getEmail())
                .password(passwordEncoder.encode(userDTO.getPassword()))
                .role(userDTO.getRole() != null ? userDTO.getRole() : Role.ROLE_USER)
                .enabled(true)
                .build();

        User saved = userRepository.save(user);
        log.info("User registered: {}", saved.getEmail());

        return new UserResponseDTO(saved.getId(), saved.getName(), saved.getEmail(), saved.getRole());
    }

    @Override
    public LoginResponseDTO loginUser(LoginRequestDTO loginDTO) {
        log.info("loginUser called");
        User user = userRepository.findByEmail(loginDTO.getEmail())
                .orElseThrow(() -> new CustomException("Invalid credentials"));

        if (!passwordEncoder.matches(loginDTO.getPassword(), user.getPassword())) {
            throw new CustomException("Invalid credentials");
        }

        String token = jwtUtil.generateToken(user);
        log.info("User logged in: {}", user.getEmail());

        return new LoginResponseDTO(token);
    }

    @Override
    public List<UserResponseDTO> getAllUsers() {
        log.info("getAllUsers called");
        return userRepository.findAll().stream()
                .map(u -> new UserResponseDTO(u.getId(), u.getName(), u.getEmail(), u.getRole()))
                .collect(Collectors.toList());
    }

    @Override
    public UserResponseDTO getUserById(Long id) {
        log.info("getUserById called");
        User user = userRepository.findById(id)
                .orElseThrow(() -> new CustomException("User not found"));

        return new UserResponseDTO(user.getId(), user.getName(), user.getEmail(), user.getRole());
    }

    @Override
    public void deleteUser(Long id) {
        log.info("deleteUser called");
        if (!userRepository.existsById(id)) {
            throw new CustomException("User not found");
        }
        userRepository.deleteById(id);
        log.info("User deleted with ID: {}", id);
    }

    @Override
    public Long extractUserIdFromToken(String authHeader) {
        log.info("extractUserIdFromToken called");
        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            throw new CustomException("Missing or invalid Authorization header");
        }
        String token = authHeader.substring(7);
        if (!jwtUtil.validateToken(token)) {
            throw new CustomException("Invalid token");
        }
        return Long.valueOf(jwtUtil.extractAllClaims(token).get("id").toString());
    }

    @Override
    public UserResponseDTO getCurrentUserProfile(Long userId) {
        log.info("getCurrentUserProfile called");
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new CustomException("User not found"));
        return new UserResponseDTO(user.getId(), user.getName(), user.getEmail(), user.getRole());
    }

    @Override
    public UserResponseDTO updateUserProfile(Long userId, UserProfileUpdateDTO updateDTO) {
        log.info("updateUserProfile called");
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new CustomException("User not found"));
        if (updateDTO.getEmail() != null && !updateDTO.getEmail().equals(user.getEmail())) {
            if (userRepository.existsByEmail(updateDTO.getEmail())) {
                throw new CustomException("Email already exists");
            }
            user.setEmail(updateDTO.getEmail());
        }
        if (updateDTO.getName() != null) {
            user.setName(updateDTO.getName());
        }
        User saved = userRepository.save(user);
        return new UserResponseDTO(saved.getId(), saved.getName(), saved.getEmail(), saved.getRole());
    }

    @Override
    public void updateUserPassword(Long userId, UserPasswordUpdateDTO passwordDTO) {
        log.info("updateUserPassword called");
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new CustomException("User not found"));
        if (!passwordEncoder.matches(passwordDTO.getOldPassword(), user.getPassword())) {
            throw new CustomException("Old password is incorrect");
        }
        user.setPassword(passwordEncoder.encode(passwordDTO.getNewPassword()));
        userRepository.save(user);
    }

    @Override
    public UserResponseDTO updateUserRole(Long id, String role) {
        log.info("updateUserRole called");
        User user = userRepository.findById(id)
                .orElseThrow(() -> new CustomException("User not found"));
        try {
            user.setRole(Role.valueOf(role));
        } catch (Exception e) {
            throw new CustomException("Invalid role");
        }
        User saved = userRepository.save(user);
        return new UserResponseDTO(saved.getId(), saved.getName(), saved.getEmail(), saved.getRole());
    }
}