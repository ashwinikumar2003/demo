package com.user_service.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.user_service.config.CustomUserDetailsService;
import com.user_service.config.JwtAuthFilter;
import com.user_service.config.JwtUtil;
import com.user_service.dto.*;
import com.user_service.entity.Role;
import com.user_service.service.UserService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;

import org.springframework.test.web.servlet.MockMvc;

import java.util.Arrays;
import java.util.List;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(controllers = UserController.class)
@MockBean({JwtUtil.class, CustomUserDetailsService.class, JwtAuthFilter.class})
class UserControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private UserService userService;

    @Autowired
    private ObjectMapper objectMapper;

    private UserResponseDTO userResponseDTO;
    private UserProfileUpdateDTO profileUpdateDTO;

    @BeforeEach
    void setUp() {
        userResponseDTO = new UserResponseDTO(1L, "John Doe", "john@example.com", Role.ROLE_USER);

        profileUpdateDTO = new UserProfileUpdateDTO();
        profileUpdateDTO.setName("Jane Doe");
        profileUpdateDTO.setEmail("jane@example.com");
    }

    @Test
    void getAllUsers_Success() throws Exception {
        List<UserResponseDTO> users = Arrays.asList(userResponseDTO);
        when(userService.getAllUsers()).thenReturn(users);

        mockMvc.perform(get("/api/users"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("OK"))
                .andExpect(jsonPath("$.message").value("All users"))
                .andExpect(jsonPath("$.data[0].name").value("John Doe"));
    }



    @Test
    void getUserById_Success() throws Exception {
        when(userService.getUserById(1L)).thenReturn(userResponseDTO);

        mockMvc.perform(get("/api/users/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("OK"))
                .andExpect(jsonPath("$.data.name").value("John Doe"));
    }

    @Test
    void deleteUser_Success() throws Exception {
        mockMvc.perform(delete("/api/users/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("OK"))
                .andExpect(jsonPath("$.message").value("User deleted"));
    }

    @Test
    void getCurrentUserProfile_Success() throws Exception {
        when(userService.extractUserIdFromToken(anyString())).thenReturn(1L);
        when(userService.getCurrentUserProfile(1L)).thenReturn(userResponseDTO);

        mockMvc.perform(get("/api/users/me")
                .header("Authorization", "Bearer jwt-token"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.name").value("John Doe"));
    }

    @Test
    void updateUserProfile_Success() throws Exception {
        when(userService.extractUserIdFromToken(anyString())).thenReturn(1L);
        when(userService.updateUserProfile(eq(1L), any(UserProfileUpdateDTO.class)))
                .thenReturn(userResponseDTO);

        mockMvc.perform(put("/api/users/me")
                .header("Authorization", "Bearer jwt-token")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(profileUpdateDTO)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message").value("Profile updated"));
    }

    @Test
    void updateUserPassword_Success() throws Exception {
        UserPasswordUpdateDTO passwordDTO = new UserPasswordUpdateDTO();
        passwordDTO.setOldPassword("oldPass");
        passwordDTO.setNewPassword("newPass");

        when(userService.extractUserIdFromToken(anyString())).thenReturn(1L);

        mockMvc.perform(put("/api/users/me/password")
                .header("Authorization", "Bearer jwt-token")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(passwordDTO)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message").value("Password updated"));
    }

    @Test
    void updateUserRole_Success() throws Exception {
        when(userService.updateUserRole(1L, "ROLE_ADMIN")).thenReturn(userResponseDTO);

        mockMvc.perform(put("/api/users/1/role")
                .param("role", "ROLE_ADMIN"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message").value("Role updated"));
    }
}