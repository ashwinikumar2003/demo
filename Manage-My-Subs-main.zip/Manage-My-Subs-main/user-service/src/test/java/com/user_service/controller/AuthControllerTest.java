package com.user_service.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.user_service.config.CustomUserDetailsService;
import com.user_service.config.JwtAuthFilter;
import com.user_service.config.JwtUtil;
import com.user_service.config.SecurityConfig;
import com.user_service.dto.*;
import com.user_service.entity.Role;
import com.user_service.service.UserService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import com.user_service.config.TestSecurityConfig;

@WebMvcTest(controllers = AuthController.class)
@Import(TestSecurityConfig.class)
@MockBean({JwtUtil.class, CustomUserDetailsService.class, JwtAuthFilter.class})
class AuthControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private UserService userService;

    @Autowired
    private ObjectMapper objectMapper;

    private UserRegistrationDTO registrationDTO;
    private LoginRequestDTO loginRequestDTO;
    private UserResponseDTO userResponseDTO;
    private LoginResponseDTO loginResponseDTO;



    @BeforeEach
    void setUp() {
        registrationDTO = new UserRegistrationDTO();
        registrationDTO.setName("John Doe");
        registrationDTO.setEmail("john@example.com");
        registrationDTO.setPassword("password123");
        registrationDTO.setRole(Role.ROLE_USER);

        loginRequestDTO = new LoginRequestDTO();
        loginRequestDTO.setEmail("john@example.com");
        loginRequestDTO.setPassword("password123");

        userResponseDTO = new UserResponseDTO(1L, "John Doe", "john@example.com", Role.ROLE_USER);
        loginResponseDTO = new LoginResponseDTO("jwt-token");
    }

    @Test
    void register_Success() throws Exception {
        when(userService.registerUser(any(UserRegistrationDTO.class))).thenReturn(userResponseDTO);

        mockMvc.perform(post("/api/auth/register")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(registrationDTO)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("OK"))
                .andExpect(jsonPath("$.message").value("User registered"))
                .andExpect(jsonPath("$.data.name").value("John Doe"))
                .andExpect(jsonPath("$.data.email").value("john@example.com"));
    }

    @Test
    void register_ValidationError_BadRequest() throws Exception {
        registrationDTO.setEmail("");

        mockMvc.perform(post("/api/auth/register")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(registrationDTO)))
                .andExpect(status().isBadRequest());
    }

    @Test
    void login_Success() throws Exception {
        when(userService.loginUser(any(LoginRequestDTO.class))).thenReturn(loginResponseDTO);

        mockMvc.perform(post("/api/auth/login")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(loginRequestDTO)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("OK"))
                .andExpect(jsonPath("$.message").value("Login successful"))
                .andExpect(jsonPath("$.data.token").value("jwt-token"))
                .andExpect(jsonPath("$.data.email").value("john@example.com"));
    }

    @Test
    void login_ValidationError_BadRequest() throws Exception {
        loginRequestDTO.setPassword("");

        mockMvc.perform(post("/api/auth/login")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(loginRequestDTO)))
                .andExpect(status().isBadRequest());
    }
}