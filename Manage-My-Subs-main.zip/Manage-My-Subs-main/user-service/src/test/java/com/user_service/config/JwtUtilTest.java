package com.user_service.config;

import com.user_service.entity.Role;
import com.user_service.entity.User;
import io.jsonwebtoken.Claims;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;

import static org.junit.jupiter.api.Assertions.*;

class JwtUtilTest {

    private JwtUtil jwtUtil;
    private final String testSecret = "CkH4QG9K6ZwRJgMtMTg1NTRERUYzQTE2NDU1QzQzM0ZEM0MxQUJDREVGMTIzNDU2";
    private final long testExpiration = 86400000L;
    private User testUser;

    @BeforeEach
    void setUp() {
        jwtUtil = new JwtUtil();
        ReflectionTestUtils.setField(jwtUtil, "jwtSecret", testSecret);
        ReflectionTestUtils.setField(jwtUtil, "jwtExpirationMs", testExpiration);
        jwtUtil.init();
        
        testUser = User.builder()
                .id(1L)
                .email("test@example.com")
                .role(Role.ROLE_USER)
                .build();
    }

    @Test
    void generateToken_ValidInputs_ReturnsToken() {
        String token = jwtUtil.generateToken(testUser);

        assertNotNull(token);
        assertFalse(token.isEmpty());
        assertTrue(token.startsWith("eyJ"));
    }

    @Test
    void extractUsername_ValidToken_ReturnsEmail() {
        String token = jwtUtil.generateToken(testUser);

        String email = jwtUtil.extractUsername(token);

        assertEquals("test@example.com", email);
    }

    @Test
    void extractAllClaims_ValidToken_ReturnsClaims() {
        String token = jwtUtil.generateToken(testUser);

        Claims claims = jwtUtil.extractAllClaims(token);

        assertNotNull(claims);
        assertEquals("test@example.com", claims.getSubject());
        assertEquals(1L, claims.get("id", Integer.class).longValue());
        assertEquals("ROLE_USER", claims.get("role", String.class));
    }

    @Test
    void validateToken_ValidToken_ReturnsTrue() {
        String token = jwtUtil.generateToken(testUser);

        boolean isValid = jwtUtil.validateToken(token);

        assertTrue(isValid);
    }

    @Test
    void validateToken_InvalidToken_ReturnsFalse() {
        String invalidToken = "invalid.token.here";

        boolean isValid = jwtUtil.validateToken(invalidToken);

        assertFalse(isValid);
    }
}