# Manage-My-Subs
A spring boot based subscription tracker
