package com.payment_service.service;

import com.payment_service.dto.PaymentDTO;
import com.payment_service.dto.PaymentResponseDTO;

import jakarta.servlet.http.HttpServletRequest;

import java.util.List;

public interface PaymentService {
    PaymentResponseDTO createPayment(PaymentDTO dto, Long userId, HttpServletRequest request);
    List<PaymentResponseDTO> getUserPayments(Long userId);
    PaymentResponseDTO updatePayment(Long id, PaymentDTO dto, Long userId);
    void deletePayment(Long id, Long userId);
    List<PaymentResponseDTO> getPaymentsBySubscription(Long subscriptionId, Long userId);
}