package com.payment_service.service;

import com.payment_service.client.AlertServiceFeignClient;
import com.payment_service.dto.PaymentDTO;
import com.payment_service.dto.PaymentResponseDTO;
import com.payment_service.entity.Payment;
import com.payment_service.exception.CustomException;
import com.payment_service.repository.PaymentRepository;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class PaymentServiceImpl implements PaymentService {

    private final PaymentRepository repository;
    private final AlertServiceFeignClient alertServiceFeignClient;

    @Override
    public PaymentResponseDTO createPayment(PaymentDTO dto, Long userId,  HttpServletRequest request) {
        log.info("createPayment called");
        Payment payment = Payment.builder()
                .userId(userId)
                .subscriptionId(dto.getSubscriptionId())
                .paymentDate(dto.getPaymentDate())
                .amount(dto.getAmount())
                .currency(dto.getCurrency())
                .paymentMethod(dto.getPaymentMethod())
                .status(dto.getStatus())
                .build();

        Payment saved = repository.save(payment);
        log.info("Created payment for user {}", userId);
        // Trigger alert creation
        try {
            String authHeader = request.getHeader(HttpHeaders.AUTHORIZATION);
        
        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            throw new CustomException("Missing or invalid Authorization header");
        }
            alertServiceFeignClient.createPaymentAlert(saved.getSubscriptionId(), saved.getAmount(), saved.getStatus(), authHeader);
        } catch (Exception e) {
            log.warn("Failed to notify alert-service for payment: {}", e.getMessage());
        }
        return mapToResponse(saved);
    }

    @Override
    public List<PaymentResponseDTO> getUserPayments(Long userId) {
        log.info("getUserPayments called");
        return repository.findByUserId(userId).stream()
                .map(this::mapToResponse)
                .toList();
    }

    @Override
    public PaymentResponseDTO updatePayment(Long id, PaymentDTO dto, Long userId) {
        log.info("updatePayment called");
        Payment payment = repository.findById(id)
                .orElseThrow(() -> new CustomException("Payment not found"));

        if (!payment.getUserId().equals(userId))
            throw new CustomException("Unauthorized");

        payment.setSubscriptionId(dto.getSubscriptionId());
        payment.setPaymentDate(dto.getPaymentDate());
        payment.setAmount(dto.getAmount());
        payment.setCurrency(dto.getCurrency());
        payment.setPaymentMethod(dto.getPaymentMethod());
        payment.setStatus(dto.getStatus());

        Payment updated = repository.save(payment);
        log.info("Updated payment {} by user {}", id, userId);
        return mapToResponse(updated);
    }

    @Override
    public void deletePayment(Long id, Long userId) {
        log.info("deletePayment called");
        Payment payment = repository.findById(id)
                .orElseThrow(() -> new CustomException("Payment not found"));

        if (!payment.getUserId().equals(userId))
            throw new CustomException("Unauthorized");

        repository.delete(payment);
        log.info("Deleted payment {} by user {}", id, userId);
    }

    @Override
    public List<PaymentResponseDTO> getPaymentsBySubscription(Long subscriptionId, Long userId) {
        log.info("getPaymentsBySubscription called");
        return repository.findBySubscriptionIdAndUserId(subscriptionId, userId).stream()
                .map(this::mapToResponse)
                .toList();
    }

    private PaymentResponseDTO mapToResponse(Payment p) {
        return new PaymentResponseDTO(
                p.getId(),
                p.getSubscriptionId(),
                p.getPaymentDate(),
                p.getAmount(),
                p.getCurrency(),
                p.getPaymentMethod(),
                p.getStatus()
        );
    }
}
