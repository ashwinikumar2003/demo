package com.payment_service.controller;

import com.payment_service.dto.ApiResponse;
import com.payment_service.dto.PaymentDTO;
import com.payment_service.dto.PaymentResponseDTO;
import com.payment_service.exception.CustomException;
import com.payment_service.security.JwtUtil;
import com.payment_service.service.PaymentService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("/api/payments")
@RequiredArgsConstructor
public class PaymentController {

    private final PaymentService service;
    private final JwtUtil jwtUtil;

    private Long extractUserId(HttpServletRequest request) {
        String authHeader = request.getHeader("Authorization");
        String token = authHeader != null && authHeader.startsWith("Bearer ") ? authHeader.substring(7) : null;
        if (token == null || !jwtUtil.validateToken(token)) throw new CustomException("Invalid token");
        return Long.valueOf(jwtUtil.extractAllClaims(token).get("id").toString());
    }

    @PostMapping
    public ResponseEntity<ApiResponse<PaymentResponseDTO>> create(@Valid @RequestBody PaymentDTO dto, HttpServletRequest request) {
        Long userId = extractUserId(request);
        return ResponseEntity.ok(new ApiResponse<>(HttpStatus.CREATED, "Created", service.createPayment(dto, userId, request)));
    }

    @GetMapping
    public ResponseEntity<ApiResponse<List<PaymentResponseDTO>>> getAll(HttpServletRequest request) {
        Long userId = extractUserId(request);
        return ResponseEntity.ok(new ApiResponse<>(HttpStatus.OK, "Fetched", service.getUserPayments(userId)));
    }

    @PutMapping("/{id}")
    public ResponseEntity<ApiResponse<PaymentResponseDTO>> update(@PathVariable Long id,
                                                                  @Valid @RequestBody PaymentDTO dto,
                                                                  HttpServletRequest request) {
        Long userId = extractUserId(request);
        return ResponseEntity.ok(new ApiResponse<>(HttpStatus.OK, "Updated", service.updatePayment(id, dto, userId)));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse<Void>> delete(@PathVariable Long id, HttpServletRequest request) {
        Long userId = extractUserId(request);
        service.deletePayment(id, userId);
        return ResponseEntity.ok(new ApiResponse<>(HttpStatus.OK, "Deleted", null));
    }

    @GetMapping("/subscription/{subscriptionId}")
    public ResponseEntity<ApiResponse<List<PaymentResponseDTO>>> getPaymentsBySubscription(
            @PathVariable Long subscriptionId,
            HttpServletRequest request
    ) {
        Long userId = extractUserId(request);
        return ResponseEntity.ok(
                new ApiResponse<>(HttpStatus.OK, "Fetched payments for subscription", 
                        service.getPaymentsBySubscription(subscriptionId, userId))
        );
    }
    
}