// package com.payment_service.service;

// import com.payment_service.client.SubscriptionServiceClient;
// import com.payment_service.dto.SubscriptionResponseDTO;
// import com.payment_service.exception.CustomException;
// import feign.FeignException;
// import lombok.RequiredArgsConstructor;
// import lombok.extern.slf4j.Slf4j;
// import org.springframework.http.ResponseEntity;
// import org.springframework.stereotype.Service;

// @Service
// @RequiredArgsConstructor
// @Slf4j
// public class SubscriptionServiceIntegration {

//     private final SubscriptionServiceClient subscriptionServiceClient;

//     public boolean validateSubscription(Long userId, Long subscriptionId, String authToken) {
//         try {
//             log.info("Validating subscription: userId={}, subscriptionId={}", userId, subscriptionId);
//             ResponseEntity<Object> response = subscriptionServiceClient.validateSubscription(
//                     userId, subscriptionId, authToken);
            
//             if (response.getBody() == null) {
//                 return false;
//             }
            
//             // Extract validation data from the nested response structure
//             @SuppressWarnings("unchecked")
//             var apiResponse = (java.util.LinkedHashMap<String, Object>) response.getBody();
//             var isValid = (Boolean) apiResponse.get("data");
            
//             return Boolean.TRUE.equals(isValid);
//         } catch (FeignException e) {
//             log.error("Error validating subscription: {}", e.getMessage());
//             return false;
//         }
//     }

//     public SubscriptionResponseDTO getSubscriptionDetails(Long subscriptionId, String authToken) {
//         try {
//             log.info("Fetching subscription details for subscriptionId: {}", subscriptionId);
//             ResponseEntity<Object> response = subscriptionServiceClient.getSubscriptionById(
//                     subscriptionId, authToken);
            
//             if (response.getBody() == null) {
//                 throw new CustomException("Subscription not found");
//             }
            
//             // Extract subscription data from the nested response structure
//             @SuppressWarnings("unchecked")
//             var apiResponse = (java.util.LinkedHashMap<String, Object>) response.getBody();
//             var subData = (java.util.LinkedHashMap<String, Object>) apiResponse.get("data");
            
//             SubscriptionResponseDTO dto = new SubscriptionResponseDTO();
//             dto.setId(Long.valueOf(subData.get("id").toString()));
//             dto.setUserId(Long.valueOf(subData.get("userId").toString()));
//             dto.setSubscriptionName((String) subData.get("subscriptionName"));
//             dto.setProviderName((String) subData.get("providerName"));
//             dto.setCategory((String) subData.get("category"));
//             // Parse date string to LocalDate if needed
//             dto.setAmount(Double.valueOf(subData.get("amount").toString()));
//             dto.setCurrency((String) subData.get("currency"));
//             dto.setFrequency((String) subData.get("frequency"));
//             dto.setActive((Boolean) subData.get("isActive"));
            
//             return dto;
//         } catch (FeignException e) {
//             log.error("Error fetching subscription details: {}", e.getMessage());
//             throw new CustomException("Failed to fetch subscription details: " + e.getMessage());
//         }
//     }
// } 