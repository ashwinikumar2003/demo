// package com.payment_service.service;

// import com.payment_service.client.UserServiceClient;
// import com.payment_service.dto.UserResponseDTO;
// import com.payment_service.exception.CustomException;
// import feign.FeignException;
// import lombok.RequiredArgsConstructor;
// import lombok.extern.slf4j.Slf4j;
// import org.springframework.http.ResponseEntity;
// import org.springframework.stereotype.Service;

// @Service
// @RequiredArgsConstructor
// @Slf4j
// public class UserServiceIntegration {

//     private final UserServiceClient userServiceClient;

//     public UserResponseDTO getUserDetails(Long userId, String authToken) {
//         try {
//             log.info("Fetching user details for userId: {}", userId);
//             ResponseEntity<Object> response = userServiceClient.getUserById(userId, authToken);
            
//             if (response.getBody() == null) {
//                 throw new CustomException("User not found");
//             }
            
//             // Extract user data from the nested response structure
//             @SuppressWarnings("unchecked")
//             var apiResponse = (java.util.LinkedHashMap<String, Object>) response.getBody();
//             var userData = (java.util.LinkedHashMap<String, Object>) apiResponse.get("data");
            
//             UserResponseDTO userDTO = new UserResponseDTO();
//             userDTO.setId(Long.valueOf(userData.get("id").toString()));
//             userDTO.setName((String) userData.get("name"));
//             userDTO.setEmail((String) userData.get("email"));
//             userDTO.setRole((String) userData.get("role"));
            
//             return userDTO;
//         } catch (FeignException e) {
//             log.error("Error fetching user details: {}", e.getMessage());
//             throw new CustomException("Failed to fetch user details: " + e.getMessage());
//         }
//     }

//     public boolean validateUser(String authToken) {
//         try {
//             ResponseEntity<Boolean> response = userServiceClient.validateUser(authToken);
//             return Boolean.TRUE.equals(response.getBody());
//         } catch (FeignException e) {
//             log.error("Error validating user: {}", e.getMessage());
//             return false;
//         }
//     }
// } 