package com.payment_service.entity;

public enum Currency{
    USD,EUR,JPY,INR
}
