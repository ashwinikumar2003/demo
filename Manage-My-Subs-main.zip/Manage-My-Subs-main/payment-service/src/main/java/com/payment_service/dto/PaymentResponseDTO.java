package com.payment_service.dto;

import com.payment_service.entity.Currency;
import lombok.AllArgsConstructor;
import lombok.Data;

import java.time.LocalDate;

@Data
@AllArgsConstructor
public class PaymentResponseDTO {
    private Long id;
    private Long subscriptionId;
    private LocalDate paymentDate;
    private Double amount;
    private Currency currency;
    private String paymentMethod;
    private String status;
}
