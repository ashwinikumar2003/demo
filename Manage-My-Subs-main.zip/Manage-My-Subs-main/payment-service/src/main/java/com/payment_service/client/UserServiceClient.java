package com.payment_service.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;

@FeignClient(name = "user-service")
public interface UserServiceClient {
    
    @GetMapping("/api/users/{id}")
    ResponseEntity<Object> getUserById(@PathVariable("id") Long id, 
                                       @RequestHeader("Authorization") String authHeader);
    
    @GetMapping("/api/users/validate")
    ResponseEntity<Boolean> validateUser(@RequestHeader("Authorization") String authHeader);
} 