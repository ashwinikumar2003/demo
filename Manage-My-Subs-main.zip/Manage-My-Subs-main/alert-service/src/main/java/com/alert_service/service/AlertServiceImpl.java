package com.alert_service.service;

import com.alert_service.dto.SubscriptionResponseDTO;
import com.alert_service.entity.Alert;
import com.alert_service.entity.AlertPriority;
import com.alert_service.entity.AlertType;
import com.alert_service.exception.CustomException;
import com.alert_service.repository.AlertRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class AlertServiceImpl implements AlertService {
    private final AlertRepository alertRepository;
    private final SubscriptionServiceIntegration subscriptionServiceIntegration;

    @Override
    public List<Alert> getUserAlerts(Long userId) {
        return alertRepository.findByUserIdOrderByAlertDateDesc(userId);
    }

    @Override
    public Alert createSubscriptionAddedAlert(Long userId, Long subscriptionId) {
        String msg = String.format("New subscription added (ID: %d)", subscriptionId);
        Alert alert = Alert.builder()
                .userId(userId)
                .subscriptionId(subscriptionId)
                .alertDate(LocalDate.now())
                .alertMessage(msg)
                .priority(AlertPriority.LOW)
                .isRead(false)
                .alertType(AlertType.GENERAL_NOTIFICATION)
                .build();
        return alertRepository.save(alert);
    }

    @Override
    public Alert createPaymentAlert(Long userId, Long subscriptionId, double amount, String status) {
        String msg;
        AlertPriority priority;
        AlertType type;
        if ("SUCCESS".equalsIgnoreCase(status)) {
            msg = String.format("Payment of $%.2f successful for subscription #%d", amount, subscriptionId);
            priority = AlertPriority.LOW;
            type = AlertType.PAYMENT_SUCCESS;
        } else {
            msg = String.format("Payment of $%.2f failed for subscription #%d", amount, subscriptionId);
            priority = AlertPriority.HIGH;
            type = AlertType.PAYMENT_FAILURE;
        }
        Alert alert = Alert.builder()
                .userId(userId)
                .subscriptionId(subscriptionId)
                .alertDate(LocalDate.now())
                .alertMessage(msg)
                .priority(priority)
                .isRead(false)
                .alertType(type)
                .build();
        return alertRepository.save(alert);
    }

    @Override
    public Alert markAlertAsRead(Long alertId, Long userId) {
        Alert alert = alertRepository.findById(alertId)
                .orElseThrow(() -> new CustomException("Alert not found"));
        if (!alert.getUserId().equals(userId)) {
            throw new CustomException("Unauthorized access");
        }
        alert.setRead(true);
        return alertRepository.save(alert);
    }

    @Override
    @Scheduled(cron = "0 0 9 * * ?") // Daily at 9 AM
    public void checkSubscriptionAlerts() {
        log.info("Running scheduled subscription alerts check");
        try {
            List<SubscriptionResponseDTO> allSubscriptions = subscriptionServiceIntegration.getAllActiveSubscriptions();
            LocalDate today = LocalDate.now();
            
            for (SubscriptionResponseDTO sub : allSubscriptions) {
                if (!sub.isActive() || sub.getStartDate() == null) continue;
                
                LocalDate nextRenewal = calculateNextRenewal(sub.getStartDate(), sub.getFrequency());
                long daysUntilRenewal = ChronoUnit.DAYS.between(today, nextRenewal);
                
                // Check if subscription expired
                if (daysUntilRenewal < 0) {
                    createExpiryAlert(sub.getUserId(), sub.getId(), sub.getSubscriptionName(), Math.abs(daysUntilRenewal));
                }
                // Check if subscription expires soon (3 days for monthly, 7 days for yearly)
                else if (("MONTHLY".equals(sub.getFrequency()) && daysUntilRenewal <= 3) ||
                         ("YEARLY".equals(sub.getFrequency()) && daysUntilRenewal <= 7)) {
                    createRenewalAlert(sub.getUserId(), sub.getId(), sub.getSubscriptionName(), daysUntilRenewal);
                }
            }
        } catch (Exception e) {
            log.error("Error in scheduled alert check: {}", e.getMessage());
        }
    }
    
    private LocalDate calculateNextRenewal(LocalDate startDate, String frequency) {
        LocalDate today = LocalDate.now();
        LocalDate nextRenewal = startDate;
        
        while (nextRenewal.isBefore(today) || nextRenewal.isEqual(today)) {
            switch (frequency) {
                case "MONTHLY":
                    nextRenewal = nextRenewal.plusMonths(1);
                    break;
                case "YEARLY":
                    nextRenewal = nextRenewal.plusYears(1);
                    break;
                case "WEEKLY":
                    nextRenewal = nextRenewal.plusWeeks(1);
                    break;
                default:
                    nextRenewal = nextRenewal.plusMonths(1);
            }
        }
        return nextRenewal;
    }
    
    private void createRenewalAlert(Long userId, Long subscriptionId, String subscriptionName, long daysLeft) {
        // Check if alert already exists for this subscription today
        boolean alertExists = alertRepository.existsByUserIdAndSubscriptionIdAndAlertDateAndAlertType(
            userId, subscriptionId, LocalDate.now(), AlertType.SUBSCRIPTION_RENEWAL);
        
        if (!alertExists) {
            String msg = String.format("%s renews in %d day%s", subscriptionName, daysLeft, daysLeft == 1 ? "" : "s");
            Alert alert = Alert.builder()
                    .userId(userId)
                    .subscriptionId(subscriptionId)
                    .alertDate(LocalDate.now())
                    .alertMessage(msg)
                    .priority(AlertPriority.MEDIUM)
                    .isRead(false)
                    .alertType(AlertType.SUBSCRIPTION_RENEWAL)
                    .build();
            alertRepository.save(alert);
        }
    }
    
    private void createExpiryAlert(Long userId, Long subscriptionId, String subscriptionName, long daysOverdue) {
        // Check if alert already exists for this subscription today
        boolean alertExists = alertRepository.existsByUserIdAndSubscriptionIdAndAlertDateAndAlertType(
            userId, subscriptionId, LocalDate.now(), AlertType.SUBSCRIPTION_EXPIRY);
        
        if (!alertExists) {
            String msg = String.format("%s expired %d day%s ago", subscriptionName, daysOverdue, daysOverdue == 1 ? "" : "s");
            Alert alert = Alert.builder()
                    .userId(userId)
                    .subscriptionId(subscriptionId)
                    .alertDate(LocalDate.now())
                    .alertMessage(msg)
                    .priority(AlertPriority.HIGH)
                    .isRead(false)
                    .alertType(AlertType.SUBSCRIPTION_EXPIRY)
                    .build();
            alertRepository.save(alert);
        }
    }
}
