package com.alert_service.service;

import com.alert_service.client.PaymentServiceClient;
import com.alert_service.dto.PaymentResponseDTO;
import com.alert_service.exception.CustomException;
import feign.FeignException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class PaymentServiceIntegration {

    private final PaymentServiceClient paymentServiceClient;

    public List<PaymentResponseDTO> getUserPayments(String authToken) {
        try {
            log.info("Fetching user payments");
            ResponseEntity<Object> response = paymentServiceClient.getUserPayments(authToken);
            
            if (response.getBody() == null) {
                return new ArrayList<>();
            }
            
            @SuppressWarnings("unchecked")
            var apiResponse = (java.util.LinkedHashMap<String, Object>) response.getBody();
            var paymentsData = (List<java.util.LinkedHashMap<String, Object>>) apiResponse.get("data");
            
            List<PaymentResponseDTO> payments = new ArrayList<>();
            for (var paymentData : paymentsData) {
                PaymentResponseDTO dto = new PaymentResponseDTO();
                dto.setId(Long.valueOf(paymentData.get("id").toString()));
                dto.setSubscriptionId(Long.valueOf(paymentData.get("subscriptionId").toString()));
                
                String paymentDateStr = (String) paymentData.get("paymentDate");
                if (paymentDateStr != null) {
                    dto.setPaymentDate(LocalDate.parse(paymentDateStr));
                }
                
                if (paymentData.get("amount") != null) {
                    dto.setAmount(Double.valueOf(paymentData.get("amount").toString()));
                }
                dto.setCurrency((String) paymentData.get("currency"));
                dto.setPaymentMethod((String) paymentData.get("paymentMethod"));
                dto.setStatus((String) paymentData.get("status"));
                
                payments.add(dto);
            }
            
            return payments;
        } catch (FeignException e) {
            log.error("Error fetching user payments: {}", e.getMessage());
            throw new CustomException("Failed to fetch user payments: " + e.getMessage());
        }
    }

    public PaymentResponseDTO getPaymentById(Long paymentId, String authToken) {
        try {
            log.info("Fetching payment details for paymentId: {}", paymentId);
            ResponseEntity<Object> response = paymentServiceClient.getPaymentById(paymentId, authToken);
            
            if (response.getBody() == null) {
                throw new CustomException("Payment not found");
            }
            
            @SuppressWarnings("unchecked")
            var apiResponse = (java.util.LinkedHashMap<String, Object>) response.getBody();
            var paymentData = (java.util.LinkedHashMap<String, Object>) apiResponse.get("data");
            
            PaymentResponseDTO dto = new PaymentResponseDTO();
            dto.setId(Long.valueOf(paymentData.get("id").toString()));
            dto.setSubscriptionId(Long.valueOf(paymentData.get("subscriptionId").toString()));
            
            String paymentDateStr = (String) paymentData.get("paymentDate");
            if (paymentDateStr != null) {
                dto.setPaymentDate(LocalDate.parse(paymentDateStr));
            }
            
            if (paymentData.get("amount") != null) {
                dto.setAmount(Double.valueOf(paymentData.get("amount").toString()));
            }
            dto.setCurrency((String) paymentData.get("currency"));
            dto.setPaymentMethod((String) paymentData.get("paymentMethod"));
            dto.setStatus((String) paymentData.get("status"));
            
            return dto;
        } catch (FeignException e) {
            log.error("Error fetching payment details: {}", e.getMessage());
            throw new CustomException("Failed to fetch payment details: " + e.getMessage());
        }
    }
} 