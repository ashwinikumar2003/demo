package com.alert_service.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class SubscriptionResponseDTO {
    private Long id;
    private Long userId;
    private String subscriptionName;
    private String providerName;
    private String category;
    private LocalDate startDate;
    private Double amount;
    private String currency;
    private String frequency;
    private boolean isActive;
} 