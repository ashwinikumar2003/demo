package com.alert_service.repository;

import com.alert_service.entity.Alert;
import com.alert_service.entity.AlertType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface AlertRepository extends JpaRepository<Alert, Long> {
    List<Alert> findByUserIdOrderByAlertDateDesc(Long userId);
    boolean existsByUserIdAndSubscriptionIdAndAlertDateAndAlertType(Long userId, Long subscriptionId, LocalDate alertDate, AlertType alertType);
}
