package com.alert_service.controller;

import com.alert_service.entity.Alert;
import com.alert_service.entity.ApiResponse;
import com.alert_service.exception.CustomException;
import com.alert_service.security.JwtUtil;
import com.alert_service.service.AlertService;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;


@RestController
@RequestMapping("/api/alerts")
@RequiredArgsConstructor
@Tag(name = "Alert API")
public class AlertController {
    private final AlertService alertService;
    private final JwtUtil jwtUtil;

    private Long extractUserId(HttpServletRequest request) {
        String authHeader = request.getHeader("Authorization");
        String token = authHeader != null && authHeader.startsWith("Bearer ") ? authHeader.substring(7) : null;
        if (token == null || !jwtUtil.validateToken(token)) throw new CustomException("Invalid token");
        return Long.valueOf(jwtUtil.extractAllClaims(token).get("id").toString());
    }

    @GetMapping("/test")
    public String test() {
        return "Alert Service is listening on port !!";
    }
    

    @GetMapping
    public ResponseEntity<ApiResponse<List<Alert>>> getUserAlerts(HttpServletRequest request) {
        Long userId = extractUserId(request);
        return ResponseEntity.ok(new ApiResponse<>(HttpStatus.OK, "Fetched", alertService.getUserAlerts(userId)));
    }

    @PostMapping("/subscription/added")
    public ResponseEntity<ApiResponse<Alert>> createSubscriptionAddedAlert(
            @RequestParam Long subscriptionId,
            HttpServletRequest request
    ) {
        Long userId = extractUserId(request);
        Alert alert = alertService.createSubscriptionAddedAlert(userId, subscriptionId);
        return ResponseEntity.ok(new ApiResponse<>(HttpStatus.CREATED, "Alert created", alert));
    }

    @PostMapping("/payment")
    public ResponseEntity<ApiResponse<Alert>> createPaymentAlert(
            @RequestParam Long subscriptionId,
            @RequestParam double amount,
            @RequestParam String status,
            HttpServletRequest request
    ) {
        Long userId = extractUserId(request);
        Alert alert = alertService.createPaymentAlert(userId, subscriptionId, amount, status);
        return ResponseEntity.ok(new ApiResponse<>(HttpStatus.CREATED, "Payment alert created", alert));
    }

    @PutMapping("/{alertId}/read")
    public ResponseEntity<ApiResponse<Alert>> markAlertAsRead(
            @PathVariable Long alertId,
            HttpServletRequest request
    ) {
        Long userId = extractUserId(request);
        Alert alert = alertService.markAlertAsRead(alertId, userId);
        return ResponseEntity.ok(new ApiResponse<>(HttpStatus.OK, "Alert marked as read", alert));
    }
}
