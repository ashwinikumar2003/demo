package com.alert_service.entity;

public enum AlertType {
    SUBSCRIPTION_RENEWAL,
    SUBSCRIPTION_EXPIRY,
    PAYMENT_SUCCESS,
    PAYMENT_FAILURE,
    PRICE_CHANGE,
    GENERAL_NOTIFICATION
} 