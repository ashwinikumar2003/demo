package com.alert_service.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PaymentResponseDTO {
    private Long id;
    private Long subscriptionId;
    private LocalDate paymentDate;
    private Double amount;
    private String currency;
    private String paymentMethod;
    private String status;
} 