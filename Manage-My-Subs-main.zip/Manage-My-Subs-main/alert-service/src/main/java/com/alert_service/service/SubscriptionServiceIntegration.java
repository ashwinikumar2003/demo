package com.alert_service.service;

import com.alert_service.client.SubscriptionServiceClient;
import com.alert_service.dto.SubscriptionResponseDTO;
import com.alert_service.exception.CustomException;
import feign.FeignException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class SubscriptionServiceIntegration {

    private final SubscriptionServiceClient subscriptionServiceClient;

    public List<SubscriptionResponseDTO> getUserSubscriptions(String authToken) {
        try {
            log.info("Fetching user subscriptions");
            ResponseEntity<Object> response = subscriptionServiceClient.getUserSubscriptions(authToken);
            
            if (response.getBody() == null) {
                return new ArrayList<>();
            }
            
            @SuppressWarnings("unchecked")
            var apiResponse = (java.util.LinkedHashMap<String, Object>) response.getBody();
            var subscriptionsData = (List<java.util.LinkedHashMap<String, Object>>) apiResponse.get("data");
            
            List<SubscriptionResponseDTO> subscriptions = new ArrayList<>();
            for (var subData : subscriptionsData) {
                SubscriptionResponseDTO dto = new SubscriptionResponseDTO();
                dto.setId(Long.valueOf(subData.get("id").toString()));
                dto.setUserId(Long.valueOf(subData.get("userId").toString()));
                dto.setSubscriptionName((String) subData.get("subscriptionName"));
                dto.setProviderName((String) subData.get("providerName"));
                dto.setCategory((String) subData.get("category"));
                String startDateStr = (String) subData.get("startDate");
                if (startDateStr != null) {
                    dto.setStartDate(LocalDate.parse(startDateStr));
                }
                if (subData.get("amount") != null) {
                    dto.setAmount(Double.valueOf(subData.get("amount").toString()));
                }
                dto.setCurrency((String) subData.get("currency"));
                dto.setFrequency((String) subData.get("frequency"));
                Object isActiveRaw = subData.get("isActive");
                boolean isActive = false;
                if (isActiveRaw instanceof Boolean) {
                    isActive = (Boolean) isActiveRaw;
                } else if (isActiveRaw instanceof String) {
                    isActive = Boolean.parseBoolean((String) isActiveRaw);
                }
                dto.setActive(isActive);
                
                subscriptions.add(dto);
            }
            
            return subscriptions;
        } catch (FeignException e) {
            log.error("Error fetching user subscriptions: {}", e.getMessage());
            throw new CustomException("Failed to fetch user subscriptions: " + e.getMessage());
        }
    }

    public List<SubscriptionResponseDTO> getAllActiveSubscriptions() {
        try {
            log.info("Fetching all active subscriptions for alert checking");
            // This would need a system token or admin access - for now return empty list
            // In production, you'd have a system service account
            return new ArrayList<>();
        } catch (Exception e) {
            log.error("Error fetching all subscriptions: {}", e.getMessage());
            return new ArrayList<>();
        }
    }

    public SubscriptionResponseDTO getSubscriptionById(Long subscriptionId, String authToken) {
        try {
            log.info("Fetching subscription details for subscriptionId: {}", subscriptionId);
            ResponseEntity<Object> response = subscriptionServiceClient.getSubscriptionById(subscriptionId, authToken);
            
            if (response.getBody() == null) {
                throw new CustomException("Subscription not found");
            }
            
            @SuppressWarnings("unchecked")
            var apiResponse = (java.util.LinkedHashMap<String, Object>) response.getBody();
            var subData = (java.util.LinkedHashMap<String, Object>) apiResponse.get("data");
            
            SubscriptionResponseDTO dto = new SubscriptionResponseDTO();
            dto.setId(Long.valueOf(subData.get("id").toString()));
            dto.setUserId(Long.valueOf(subData.get("userId").toString()));
            dto.setSubscriptionName((String) subData.get("subscriptionName"));
            dto.setProviderName((String) subData.get("providerName"));
            dto.setCategory((String) subData.get("category"));
            String startDateStr = (String) subData.get("startDate");
            if (startDateStr != null) {
                dto.setStartDate(LocalDate.parse(startDateStr));
            }
            if (subData.get("amount") != null) {
                dto.setAmount(Double.valueOf(subData.get("amount").toString()));
            }
            dto.setCurrency((String) subData.get("currency"));
            dto.setFrequency((String) subData.get("frequency"));
            
            Object isActiveRaw = subData.get("isActive");
            boolean isActive = false;
            if (isActiveRaw instanceof Boolean) {
                isActive = (Boolean) isActiveRaw;
            } else if (isActiveRaw instanceof String) {
                isActive = Boolean.parseBoolean((String) isActiveRaw);
            }
            dto.setActive(isActive);
            
            return dto;
        } catch (FeignException e) {
            log.error("Error fetching subscription details: {}", e.getMessage());
            throw new CustomException("Failed to fetch subscription details: " + e.getMessage());
        }
    }
}