package com.alert_service.service;

import com.alert_service.entity.Alert;
import java.util.List;

public interface AlertService {
    List<Alert> getUserAlerts(Long userId);
    Alert createSubscriptionAddedAlert(Long userId, Long subscriptionId);
    Alert createPaymentAlert(Long userId, Long subscriptionId, double amount, String status);
    Alert markAlertAsRead(Long alertId, Long userId);
    void checkSubscriptionAlerts();
}
