package com.alert_service.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Alert {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long userId;
    private Long subscriptionId;
    private Long paymentId;

    private LocalDate alertDate;
    private String alertMessage;
    
    @Enumerated(EnumType.STRING)
    private AlertPriority priority;
    
    private boolean isRead;
    
    @Enumerated(EnumType.STRING)
    private AlertType alertType;


}

