package com.alert_service.entity;

public enum AlertPriority {
    HIGH,
    MEDIUM,
    LOW
} 