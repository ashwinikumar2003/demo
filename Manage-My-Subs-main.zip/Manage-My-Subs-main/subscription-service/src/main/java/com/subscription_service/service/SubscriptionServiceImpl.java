package com.subscription_service.service;

import com.subscription_service.client.AlertServiceFeignClient;
import com.subscription_service.dto.SubscriptionDTO;
import com.subscription_service.dto.SubscriptionResponseDTO;
import com.subscription_service.entity.Subscription;
import com.subscription_service.exception.CustomException;
import com.subscription_service.repository.SubscriptionRepository;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;

import java.util.List;

import java.util.stream.*;

@Service
@RequiredArgsConstructor
@Slf4j
public class SubscriptionServiceImpl implements SubscriptionService {

    private final SubscriptionRepository repository;
    private final AlertServiceFeignClient alertServiceFeignClient;

    @Override
    public SubscriptionResponseDTO createSubscription(SubscriptionDTO dto, HttpServletRequest request) {
        log.info("createSubscription called");
        Subscription subscription = mapToEntity(dto);
        Subscription saved = repository.save(subscription);
        log.info("Created subscription with ID: {}", saved.getId());
        try {
            String authHeader = request.getHeader(HttpHeaders.AUTHORIZATION);
        
            if (authHeader == null || !authHeader.startsWith("Bearer ")) {
                throw new CustomException("Missing or invalid Authorization header");
            }
            alertServiceFeignClient.createSubscriptionAddedAlert(saved.getId(), authHeader);
        } catch (Exception e) {
            log.warn("Failed to notify alert-service for subscription added: {}", e.getMessage());
        }
        return mapToDto(saved);
    }

    @Override
    public List<SubscriptionResponseDTO> getUserSubscriptions(Long userId) {
        log.info("getUserSubscriptions called");
        return repository.findAllByUserId(userId).stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    @Override
    public SubscriptionResponseDTO updateSubscription(Long id, SubscriptionDTO dto) {
        log.info("updateSubscription called");
        Subscription subscription = repository.findById(id)
                .orElseThrow(() -> new CustomException("Subscription not found"));

        if (!subscription.getUserId().equals(dto.getUserId())) {
            throw new CustomException("You are not authorized to update this subscription");
        }

        subscription.setSubscriptionName(dto.getSubscriptionName());
        subscription.setProviderName(dto.getProviderName());
        subscription.setCategory(dto.getCategory());
        subscription.setStartDate(dto.getStartDate());
        subscription.setAmount(dto.getAmount());
        subscription.setCurrency(dto.getCurrency());
        subscription.setFrequency(dto.getFrequency());
        subscription.setActive(dto.isActive());

        Subscription updated = repository.save(subscription);
        log.info("Updated subscription with ID: {}", updated.getId());
        return mapToDto(updated);
    }

    @Override
    public void deleteSubscription(Long id, Long userId) {
        log.info("deleteSubscription called");
        Subscription subscription = repository.findById(id)
                .orElseThrow(() -> new CustomException("Subscription not found"));

        if (!subscription.getUserId().equals(userId)) {
            throw new CustomException("You are not authorized to delete this subscription");
        }

        repository.delete(subscription);
        log.info("Deleted subscription with ID: {}", id);
    }


    @Override
    public SubscriptionResponseDTO getSubscriptionById(Long id) {
        log.info("getSubscriptionById called");
        Subscription subscription = repository.findById(id)
                .orElseThrow(() -> new CustomException("Subscription not found"));
        return mapToDto(subscription);
    }

    private Subscription mapToEntity(SubscriptionDTO dto) {
        return Subscription.builder()
                .userId(dto.getUserId())
                .subscriptionName(dto.getSubscriptionName())
                .providerName(dto.getProviderName())
                .category(dto.getCategory())
                .startDate(dto.getStartDate())
                .amount(dto.getAmount())
                .currency(dto.getCurrency())
                .frequency(dto.getFrequency())
                .active(dto.isActive())
                .build();
    }

    private SubscriptionResponseDTO mapToDto(Subscription entity) {
        return SubscriptionResponseDTO.builder()
                .id(entity.getId())
                .userId(entity.getUserId())
                .subscriptionName(entity.getSubscriptionName())
                .providerName(entity.getProviderName())
                .category(entity.getCategory())
                .startDate(entity.getStartDate())
                .amount(entity.getAmount())
                .currency(entity.getCurrency())
                .frequency(entity.getFrequency())
                .active(entity.isActive())
                .build();
    }
}