package com.subscription_service.controller;

import com.subscription_service.dto.SubscriptionDTO;
import com.subscription_service.dto.SubscriptionResponseDTO;
import com.subscription_service.exception.CustomException;
import com.subscription_service.service.SubscriptionService;
import com.subscription_service.security.JwtUtil;
import com.subscription_service.dto.ApiResponse;
import io.jsonwebtoken.Claims;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;

import java.util.List;

@RestController
@RequestMapping("/api/subscriptions")
@RequiredArgsConstructor
@Tag(name = "Subscription API")
public class SubscriptionController {

    private final SubscriptionService service;
    private final JwtUtil jwtUtil;

    private Long extractUserId(HttpServletRequest request) {
        String authHeader = request.getHeader(HttpHeaders.AUTHORIZATION);
        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            throw new CustomException("Missing or invalid Authorization header");
        }
        String token = authHeader.substring(7);
        if (!jwtUtil.validateToken(token)) {
            throw new CustomException("Invalid or expired token");
        }
        Claims claims = jwtUtil.extractAllClaims(token);
        return claims.get("id", Long.class);
    }

    @PostMapping
    public ResponseEntity<?> create(
            @Valid @RequestBody SubscriptionDTO dto,
            HttpServletRequest request, BindingResult result
    ) {

        if (result.hasErrors()) {
            String errorMsg = result.getFieldError().getDefaultMessage();
            return ResponseEntity.badRequest().body(errorMsg);
        }
        dto.setUserId(extractUserId(request));
        return new ResponseEntity<>(
                new ApiResponse<>(HttpStatus.CREATED, "Created", service.createSubscription(dto, request)),
                HttpStatus.CREATED
        );
    }

    @GetMapping
    public ResponseEntity<ApiResponse<List<SubscriptionResponseDTO>>> getAll(HttpServletRequest request) {
        Long userId = extractUserId(request);
        return ResponseEntity.ok(
                new ApiResponse<>(HttpStatus.OK, "Fetched", service.getUserSubscriptions(userId))
        );
    }

    @PutMapping("/{id}")
    public ResponseEntity<ApiResponse<SubscriptionResponseDTO>> update(
            @PathVariable Long id,
            @Valid @RequestBody SubscriptionDTO dto,
            HttpServletRequest request
    ) {
        dto.setUserId(extractUserId(request));
        return ResponseEntity.ok(
                new ApiResponse<>(HttpStatus.OK, "Updated", service.updateSubscription(id, dto))
        );
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse<Void>> delete(
            @PathVariable Long id,
            HttpServletRequest request
    ) {
        Long userId = extractUserId(request);
        service.deleteSubscription(id, userId);
        return ResponseEntity.ok(
                new ApiResponse<>(HttpStatus.OK, "Deleted", null)
        );
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<SubscriptionResponseDTO>> getById(@PathVariable Long id) {
        return ResponseEntity.ok(
                new ApiResponse<>(HttpStatus.OK, "Subscription fetched", service.getSubscriptionById(id))
        );
    }
}