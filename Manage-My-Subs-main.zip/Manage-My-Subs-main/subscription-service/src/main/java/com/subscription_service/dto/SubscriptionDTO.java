package com.subscription_service.dto;

import com.subscription_service.entity.Category;
import com.subscription_service.entity.Currency;
import com.subscription_service.entity.Frequency;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.Data;

import java.time.LocalDate;

@Data
public class SubscriptionDTO {
    private Long userId;
    
    @NotBlank(message = "Subscription name is required")
    private String subscriptionName;
    
    @NotBlank(message = "Provider name is required")
    private String providerName;
    
    @NotNull(message = "Category is required")
    private Category category;
    
    @NotNull(message = "Start date is required")
    private LocalDate startDate;
    
    @NotNull(message = "Amount is required")
    @Positive(message = "Amount must be positive")
    private Double amount;
    
    @NotNull(message = "Currency is required")
    private Currency currency;
    
    @NotNull(message = "Frequency is required")
    private Frequency frequency;
    
    private boolean active;
}
