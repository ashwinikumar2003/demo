package com.subscription_service.service;

import com.subscription_service.dto.SubscriptionDTO;
import com.subscription_service.dto.SubscriptionResponseDTO;
import jakarta.servlet.http.HttpServletRequest;

import java.util.List;

public interface SubscriptionService {
    SubscriptionResponseDTO createSubscription(SubscriptionDTO dto, HttpServletRequest request);
    List<SubscriptionResponseDTO> getUserSubscriptions(Long userId);
    SubscriptionResponseDTO updateSubscription(Long id, SubscriptionDTO dto);
    void deleteSubscription(Long id, Long userId);
    SubscriptionResponseDTO getSubscriptionById(Long id);
}