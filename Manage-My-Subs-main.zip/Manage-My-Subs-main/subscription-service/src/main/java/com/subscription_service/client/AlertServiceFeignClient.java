package com.subscription_service.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;

@FeignClient(name = "alert-service")
public interface AlertServiceFeignClient {
    @PostMapping("/api/alerts/subscription/added")
    ResponseEntity<Object> createSubscriptionAddedAlert(
            @RequestParam("subscriptionId") Long subscriptionId,
            @RequestHeader("Authorization") String authHeader);

    @PostMapping("/api/alerts/payment")
    ResponseEntity<Object> createPaymentAlert(
            @RequestParam("subscriptionId") Long subscriptionId,
            @RequestParam("amount") double amount,
            @RequestParam("status") String status,
            @RequestHeader("Authorization") String authHeader);
}
