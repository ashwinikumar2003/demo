package com.subscription_service.dto;

import com.subscription_service.entity.Category;
import com.subscription_service.entity.Currency;
import com.subscription_service.entity.Frequency;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class SubscriptionResponseDTO {
    private Long id;
    private Long userId;
    private String subscriptionName;
    private String providerName;
    private Category category;
    private LocalDate startDate;
    private Double amount;
    private Currency currency;
    private Frequency frequency;
    private boolean active;
}
