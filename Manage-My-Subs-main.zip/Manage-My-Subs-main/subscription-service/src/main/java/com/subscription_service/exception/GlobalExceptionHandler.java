// package com.subscription_service.exception;

// import com.subscription_service.dto.ErrorResponse;
// import org.springframework.http.HttpStatus;
// import org.springframework.http.ResponseEntity;
// import org.springframework.web.bind.MethodArgumentNotValidException;
// import org.springframework.web.bind.annotation.ExceptionHandler;
// import org.springframework.web.bind.annotation.RestControllerAdvice;

// @ControllerAdvice(basePackages = "com.subscription_service.controller")
// public class GlobalExceptionHandler {

//     @ExceptionHandler(MethodArgumentNotValidException.class)
//     public ResponseEntity<ErrorResponse> handleValidationError(MethodArgumentNotValidException ex) {
//         String message = ex.getBindingResult().getFieldErrors().get(0).getDefaultMessage();
//         return ResponseEntity.badRequest().body(
//             new ErrorResponse(message, "VALIDATION_ERROR", 400)
//         );
//     }

//     @ExceptionHandler(CustomException.class)
//     public ResponseEntity<ErrorResponse> handleCustomException(CustomException ex) {
//         return ResponseEntity.badRequest().body(
//             new ErrorResponse(ex.getMessage(), "CUSTOM_ERROR", 400)
//         );
//     }

//     @ExceptionHandler(Exception.class)
//     public ResponseEntity<ErrorResponse> handleGenericException(Exception ex) {
//         return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(
//             new ErrorResponse("Internal server error", "INTERNAL_ERROR", 500)
//         );
//     }
// }