package com.subscription_service.entity;

public enum Frequency {
    WEEKLY,
    MONTHLY,
    QUARTERLY,
    YEARLY
}