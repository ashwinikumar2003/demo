package com.subscription_service.entity;

public enum Category {
    ENTERTAINMENT,
    SOFTWARE,
    HEALTH,
    EDUCATION,
    PRODUCTIVITY,
    OTHER
}
