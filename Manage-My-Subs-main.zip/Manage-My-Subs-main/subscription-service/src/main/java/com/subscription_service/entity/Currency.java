package com.subscription_service.entity;

public enum Currency {
    USD,
    INR,
    EUR,
    JPY
}